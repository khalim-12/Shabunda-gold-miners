<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Partnership Opportunity - Lubumbashi Gold Miners</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Partnership Page Styles */
       /* Partnership Page Styles */
.partnership-hero-section {
    background: linear-gradient(135deg, var(--dark-color), #1a2530);
    color: white;
    position: relative;
    overflow: hidden;
    padding: 100px 0;
    margin-top: -76px; /* This will pull the section up to overlap with header */
}

        .partnership-hero-section::before {
            content: '';
            position: absolute;
            margin-top: -76px;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('assets/images/slide1.jpg') center/cover;
            
        }

        .hero-title {
            font-size: 3.5rem;
            font-weight: 800;
            color: var(--primary-color);
            margin-bottom: 1.5rem;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }

        .hero-subtitle {
            font-size: 1.4rem;
            color: rgba(255, 255, 255, 0.9);
            margin-bottom: 2.5rem;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
            line-height: 1.6;
        }

        .urgency-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.75rem;
            background: linear-gradient(135deg, var(--secondary-color), #ff8c5a);
            color: white;
            padding: 1rem 2rem;
            border-radius: 50px;
            font-weight: 600;
            font-size: 1.1rem;
            margin-bottom: 2rem;
            box-shadow: 0 5px 15px rgba(255, 107, 53, 0.4);
        }

        /* Problem Section */
        .problem-section {
            background: linear-gradient(135deg, #fff8f0, #ffe8cc);
            padding: 80px 0;
        }

        .problem-card {
            background: white;
            padding: 3rem;
            border-radius: 20px;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.1);
            border-left: 5px solid var(--secondary-color);
        }

        .problem-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, var(--secondary-color), #ff8c5a);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2rem;
            margin-bottom: 2rem;
        }

        /* Solution Section */
        .solution-section {
            padding: 80px 0;
            background: white;
        }

        .solution-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-top: 3rem;
        }

        .solution-card {
            background: #f8f9fa;
            padding: 2.5rem;
            border-radius: 15px;
            text-align: center;
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }

        .solution-card:hover {
            transform: translateY(-10px);
            border-color: var(--primary-color);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
        }

        .solution-icon {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, var(--primary-color), #ffed4e);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--dark-color);
            font-size: 1.8rem;
            margin: 0 auto 1.5rem;
            transition: all 0.3s ease;
        }

        .solution-card:hover .solution-icon {
            transform: scale(1.1);
            background: linear-gradient(135deg, var(--secondary-color), #ff8c5a);
            color: white;
        }

        /* Partnership Benefits */
        .benefits-section {
            background: linear-gradient(135deg, var(--dark-color), #1a2530);
            color: white;
            padding: 80px 0;
        }

        .benefit-item {
            display: flex;
            align-items: center;
            gap: 1.5rem;
            padding: 1.5rem;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            margin-bottom: 1.5rem;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
        }

        .benefit-item:hover {
            background: rgba(255, 255, 255, 0.15);
            transform: translateX(10px);
        }

        .benefit-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, var(--primary-color), #ffed4e);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--dark-color);
            font-size: 1.5rem;
            flex-shrink: 0;
        }

        /* Call to Action */
        .partnership-cta {
            background: linear-gradient(135deg, var(--primary-color), #ffed4e);
            padding: 80px 0;
            text-align: center;
        }

        .cta-title {
            color: var(--dark-color);
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 1.5rem;
        }

        .cta-subtitle {
            color: var(--dark-color);
            font-size: 1.2rem;
            margin-bottom: 2.5rem;
            opacity: 0.9;
        }

        .partnership-form {
            background: white;
            padding: 3rem;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 0 auto;
        }

        /* Impact Stats */
        .impact-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 2rem;
            margin: 3rem 0;
        }

        .impact-stat {
            text-align: center;
            padding: 2rem;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            backdrop-filter: blur(10px);
        }

        .impact-number {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }

        .impact-label {
            color: white;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-size: 0.9rem;
        }

        /* Enhanced Solution Section */
.solution-section {
    padding: 80px 0;
    background: linear-gradient(135deg, #f8f9fa, #ffffff);
}

.solution-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
    gap: 2.5rem;
    margin-top: 3rem;
}

.solution-card {
    background: white;
    padding: 2.5rem;
    border-radius: 20px;
    text-align: center;
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    border: 2px solid transparent;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
    position: relative;
    overflow: hidden;
}

.solution-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
    transform: scaleX(0);
    transition: transform 0.3s ease;
}

.solution-card:hover::before {
    transform: scaleX(1);
}

.solution-card:hover {
    transform: translateY(-15px);
    border-color: var(--primary-color);
    box-shadow: 0 20px 50px rgba(0, 0, 0, 0.15);
}

.solution-icon {
    width: 90px;
    height: 90px;
    background: linear-gradient(135deg, var(--primary-color), #ffed4e);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--dark-color);
    font-size: 2.2rem;
    margin: 0 auto 1.5rem;
    transition: all 0.3s ease;
    position: relative;
}

.solution-icon::after {
    content: '';
    position: absolute;
    top: -5px;
    left: -5px;
    right: -5px;
    bottom: -5px;
    border: 2px solid var(--primary-color);
    border-radius: 50%;
    opacity: 0;
    transition: all 0.3s ease;
}

.solution-card:hover .solution-icon {
    transform: scale(1.1) rotate(5deg);
    background: linear-gradient(135deg, var(--secondary-color), #ff8c5a);
    color: white;
}

.solution-card:hover .solution-icon::after {
    opacity: 1;
    top: -8px;
    left: -8px;
    right: -8px;
    bottom: -8px;
}

.solution-card h4 {
    color: var(--dark-color);
    font-weight: 700;
    margin-bottom: 1.25rem;
    font-size: 1.4rem;
    line-height: 1.3;
}

.solution-card p {
    color: #666;
    line-height: 1.6;
    margin-bottom: 1.5rem;
    font-size: 1rem;
}

/* Benefit Badges */
.benefit-badge {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    background: rgba(255, 215, 0, 0.1);
    color: var(--dark-color);
    padding: 0.6rem 1.2rem;
    border-radius: 25px;
    font-size: 0.9rem;
    font-weight: 600;
    margin-top: 1rem;
    border: 1px solid rgba(255, 215, 0, 0.3);
}

.benefit-badge i {
    color: var(--primary-color);
    font-size: 1rem;
}

/* Partnership Perks */
.partnership-perks {
    background: white;
    padding: 3rem;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
    margin-top: 3rem;
    border: 1px solid rgba(255, 215, 0, 0.1);
}

.partnership-perks h3 {
    color: var(--dark-color);
    font-weight: 700;
    font-size: 1.8rem;
}

.perk-item {
    text-align: center;
    padding: 1.5rem;
}

.perk-icon {
    width: 70px;
    height: 70px;
    background: linear-gradient(135deg, var(--primary-color), #ffed4e);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--dark-color);
    font-size: 1.8rem;
    margin: 0 auto 1rem;
    transition: all 0.3s ease;
}

.perk-item:hover .perk-icon {
    transform: scale(1.1);
    background: linear-gradient(135deg, var(--secondary-color), #ff8c5a);
    color: white;
}

.perk-item h5 {
    color: var(--dark-color);
    font-weight: 600;
    margin-bottom: 0.75rem;
    font-size: 1.1rem;
}

.perk-item p {
    color: #666;
    font-size: 0.9rem;
    line-height: 1.5;
    margin: 0;
}

/* Animation Enhancements */
.solution-card {
    animation: fadeInUp 0.6s ease forwards;
    opacity: 0;
    transform: translateY(30px);
}

.solution-card:nth-child(1) { animation-delay: 0.1s; }
.solution-card:nth-child(2) { animation-delay: 0.2s; }
.solution-card:nth-child(3) { animation-delay: 0.3s; }

.perk-item {
    animation: fadeInUp 0.6s ease forwards;
    opacity: 0;
    transform: translateY(20px);
}

.perk-item:nth-child(1) { animation-delay: 0.4s; }
.perk-item:nth-child(2) { animation-delay: 0.5s; }
.perk-item:nth-child(3) { animation-delay: 0.6s; }

@keyframes fadeInUp {
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Responsive Design */
@media (max-width: 768px) {
    .solution-grid {
        grid-template-columns: 1fr;
        gap: 2rem;
    }
    
    .solution-card {
        padding: 2rem;
    }
    
    .solution-icon {
        width: 80px;
        height: 80px;
        font-size: 2rem;
    }
    
    .partnership-perks {
        padding: 2rem;
    }
    
    .perk-item {
        padding: 1rem;
        margin-bottom: 1rem;
    }
}

@media (max-width: 576px) {
    .solution-card {
        padding: 1.5rem;
    }
    
    .solution-icon {
        width: 70px;
        height: 70px;
        font-size: 1.8rem;
    }
    
    .solution-card h4 {
        font-size: 1.2rem;
    }
    
    .partnership-perks {
        padding: 1.5rem;
    }
    
    .perk-icon {
        width: 60px;
        height: 60px;
        font-size: 1.5rem;
    }
}

/* Enhanced Section Titles */
.section-title {
    color: var(--dark-color);
    font-weight: 800;
    font-size: 2.5rem;
    margin-bottom: 1rem;
    position: relative;
}

.section-title::after {
    content: '';
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translateX(-50%);
    width: 80px;
    height: 4px;
    background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
    border-radius: 2px;
}

.section-subtitle {
    color: #666;
    font-size: 1.2rem;
    line-height: 1.6;
    max-width: 600px;
    margin: 0 auto;
}

        /* Responsive Design */
        @media (max-width: 768px) {
            .hero-title {
                font-size: 2.5rem;
            }
            
            .hero-subtitle {
                font-size: 1.2rem;
            }
            
            .problem-card,
            .partnership-form {
                padding: 2rem;
            }
            
            .solution-grid {
                grid-template-columns: 1fr;
            }
            
            .benefit-item {
                flex-direction: column;
                text-align: center;
            }
            
            .impact-stats {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 576px) {
            .hero-title {
                font-size: 2rem;
            }
            
            .urgency-badge {
                padding: 0.75rem 1.5rem;
                font-size: 1rem;
            }
            
            .impact-stats {
                grid-template-columns: 1fr;
            }
            
            .cta-title {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Primary Meta Tags -->
    <title>Lubumbashi Gold Miners | Gold Mining, Buying, Selling, Testing & Partnership Services DRC</title>
    <meta name="description" content="Lubumbashi Gold Miners: Complete gold services in DRC. Gold mining operations, buying raw gold, selling refined gold, XRF testing, assaying, mining partnerships, joint ventures, and community development. Ethical & sustainable practices.">
    <meta name="keywords" content="gold mining DRC, gold buying Congo, gold selling services, gold testing, XRF analyzer, gold assaying, mining partnerships, joint ventures, artisanal mining, gold exploration, mine development, gold processing, gold refining, sustainable mining, ethical gold, community mining, DRC gold, Congo minerals, mining investment, gold export, mineral rights, mining consultancy">
    <meta name="author" content="Lubumbashi Gold Miners">
    <meta name="robots" content="index, follow">

    <!-- Geographic Meta Tags -->
    <meta name="geo.region" content="CD-LU">
    <meta name="geo.placename" content="Lubumbashi">
    <meta name="geo.position" content="-11.664231;27.482626">
    <meta name="ICBM" content="-11.664231, 27.482626">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://lubumbashigoldminers.com/">
    <meta property="og:title" content="Lubumbashi Gold Miners | Complete Gold Mining & Trading Services">
    <meta property="og:description" content="DRC's premier gold services: Mining operations, gold trading, XRF testing, mining partnerships & joint ventures. Ethical practices with community empowerment.">
    <meta property="og:image" content="https://lubumbashigoldminers.com/assets/images/og-image.jpg">
    <meta property="og:image:alt" content="Lubumbashi Gold Miners - Gold Mining & Partnership Services">
    <meta property="og:site_name" content="Lubumbashi Gold Miners">
    <meta property="og:locale" content="en_US">

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="https://lubumbashigoldminers.com/">
    <meta property="twitter:title" content="Lubumbashi Gold Miners | Mining & Gold Services Experts">
    <meta property="twitter:description" content="Professional gold mining, trading, testing & partnership services in DRC. XRF testing, fair trade, and sustainable mining practices.">
    <meta property="twitter:image" content="https://lubumbashigoldminers.com/assets/images/og-image.jpg">

    <!-- Canonical URL -->
    <link rel="canonical" href="https://lubumbashigoldminers.com/">

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="favicon.png">

    <!-- Additional Icons -->
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">

    <!-- Preload Critical Resources -->
    <link rel="preload" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" as="style">
    <link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" as="style">
    <link rel="preload" href="assets/css/style.css" as="style">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- Language Alternates -->
    <link rel="alternate" hreflang="fr" href="https://lubumbashigoldminers.com/fr/" />
    <link rel="alternate" hreflang="sw" href="https://lubumbashigoldminers.com/sw/" />
    <link rel="alternate" hreflang="en" href="https://lubumbashigoldminers.com/" />

    <!-- Mobile Optimization -->
    <meta name="format-detection" content="telephone=no">
    <meta name="HandheldFriendly" content="true">
    <meta name="MobileOptimized" content="width">

    <!-- Additional SEO Meta Tags -->
    <meta name="subject" content="Gold Mining, Trading, Testing & Partnership Services in Democratic Republic of Congo">
    <meta name="classification" content="Precious Metals, Mining Services, Gold Trading, Mining Partnerships">
    <meta name="reply-to" content="contact@lubumbashigoldminers.com">
    <meta name="directory" content="submission">
    <meta name="category" content="Business">
    <meta name="coverage" content="Worldwide">
    <meta name="distribution" content="Global">
    <meta name="rating" content="General">
    <meta name="revisit-after" content="7 days">

    <!-- Comprehensive Structured Data -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "Organization",
          "@id": "https://lubumbashigoldminers.com/#organization",
          "name": "Lubumbashi Gold Miners",
          "url": "https://lubumbashigoldminers.com/",
          "logo": "https://lubumbashigoldminers.com/assets/images/logo.png",
          "description": "Complete gold mining, trading, testing and partnership services in Democratic Republic of Congo",
          "foundingDate": "2010",
          "numberOfEmployees": "50-100",
          "slogan": "Ethical Gold Mining & Sustainable Community Development",
          "address": {
            "@type": "PostalAddress",
            "streetAddress": "Lubumbashi Mining District",
            "addressLocality": "Lubumbashi",
            "addressRegion": "Haut-Katanga",
            "postalCode": "DRC001",
            "addressCountry": "CD"
          },
          "contactPoint": {
            "@type": "ContactPoint",
            "telephone": "+243 897295691",
            "contactType": "customer service",
            "email": "contact@lubumbashigoldminers.com",
            "areaServed": "CD",
            "availableLanguage": ["en", "fr", "sw"]
          },
          "sameAs": [
            "https://www.facebook.com/lubumbashigoldminers",
            "https://www.linkedin.com/company/lubumbashi-gold-miners",
            "https://twitter.com/lubumbashigold"
          ]
        },
        {
          "@type": "WebSite",
          "@id": "https://lubumbashigoldminers.com/#website",
          "url": "https://lubumbashigoldminers.com/",
          "name": "Lubumbashi Gold Miners",
          "description": "Professional gold services in DRC - Mining, Trading, Testing & Partnerships",
          "publisher": {
            "@id": "https://lubumbashigoldminers.com/#organization"
          },
          "inLanguage": "en"
        },
        {
          "@type": "LocalBusiness",
          "@id": "https://lubumbashigoldminers.com/#localbusiness",
          "name": "Lubumbashi Gold Miners",
          "image": "https://lubumbashigoldminers.com/assets/images/business-image.jpg",
          "url": "https://lubumbashigoldminers.com/",
          "telephone": "+243 897295691",
          "priceRange": "$$$",
          "address": {
            "@type": "PostalAddress",
            "streetAddress": "Lubumbashi Mining District",
            "addressLocality": "Lubumbashi",
            "addressRegion": "Haut-Katanga",
            "postalCode": "DRC001",
            "addressCountry": "CD"
          },
          "geo": {
            "@type": "GeoCoordinates",
            "latitude": -11.664231,
            "longitude": 27.482626
          },
          "openingHoursSpecification": {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": [
              "Monday",
              "Tuesday",
              "Wednesday",
              "Thursday",
              "Friday",
              "Saturday"
            ],
            "opens": "08:00",
            "closes": "18:00"
          },
          "areaServed": {
            "@type": "GeoCircle",
            "geoMidpoint": {
              "@type": "GeoCoordinates",
              "latitude": -11.664231,
              "longitude": 27.482626
            },
            "geoRadius": "500000"
          }
        }
      ]
    }
    </script>

    <!-- Services Structured Data -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "ItemList",
      "name": "Gold Mining & Trading Services",
      "description": "Complete range of gold services offered by Lubumbashi Gold Miners",
      "numberOfItems": 8,
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "item": {
            "@type": "Service",
            "name": "Gold Mining Operations",
            "description": "Professional gold mining operations with modern equipment and sustainable practices",
            "provider": {
              "@type": "Organization",
              "name": "Lubumbashi Gold Miners"
            },
            "areaServed": "Democratic Republic of Congo"
          }
        },
        {
          "@type": "ListItem",
          "position": 2,
          "item": {
            "@type": "Service",
            "name": "Gold Buying Services",
            "description": "Purchase raw gold from artisanal miners at fair market prices with transparent valuation",
            "provider": {
              "@type": "Organization",
              "name": "Lubumbashi Gold Miners"
            }
          }
        },
        {
          "@type": "ListItem",
          "position": 3,
          "item": {
            "@type": "Service",
            "name": "Gold Selling & Export",
            "description": "Sell refined and certified gold to international markets and local buyers",
            "provider": {
              "@type": "Organization",
              "name": "Lubumbashi Gold Miners"
            }
          }
        },
        {
          "@type": "ListItem",
          "position": 4,
          "item": {
            "@type": "Service",
            "name": "Gold Testing & Assaying",
            "description": "Professional gold purity testing using XRF analyzers and traditional fire assaying methods",
            "provider": {
              "@type": "Organization",
              "name": "Lubumbashi Gold Miners"
            }
          }
        },
        {
          "@type": "ListItem",
          "position": 5,
          "item": {
            "@type": "Service",
            "name": "Mining Partnerships",
            "description": "Strategic partnerships for joint mining ventures and collaborative projects",
            "provider": {
              "@type": "Organization",
              "name": "Lubumbashi Gold Miners"
            }
          }
        },
        {
          "@type": "ListItem",
          "position": 6,
          "item": {
            "@type": "Service",
            "name": "Joint Ventures",
            "description": "Equity partnerships and joint venture opportunities in gold mining projects",
            "provider": {
              "@type": "Organization",
              "name": "Lubumbashi Gold Miners"
            }
          }
        },
        {
          "@type": "ListItem",
          "position": 7,
          "item": {
            "@type": "Service",
            "name": "Mining Consultancy",
            "description": "Expert mining consultancy services including exploration and mine development",
            "provider": {
              "@type": "Organization",
              "name": "Lubumbashi Gold Miners"
            }
          }
        },
        {
          "@type": "ListItem",
          "position": 8,
          "item": {
            "@type": "Service",
            "name": "Community Mining Development",
            "description": "Support for artisanal miners and community-based mining initiatives",
            "provider": {
              "@type": "Organization",
              "name": "Lubumbashi Gold Miners"
            }
          }
        }
      ]
    }
    </script>

    <!-- Analytics / Metrics -->
    <script defer src="https://shown.io/metrics/vg8VlMxz0k" type="text/javascript"></script>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2794078128461810" crossorigin="anonymous"></script>
</head>

<header>
    <nav class="navbar navbar-expand-lg navbar-light fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#home">
                <img src="assets/images/logo.png" alt="Lubumbashi Gold Miners" height="50" class="brand-logo">
                <span class="brand-text-full">LUBUMBASHI GOLD MINERS</span>
                <span class="brand-text-short">LUBUMBASHI GOLD...</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                                            <li class="nav-item">
                            <a class="nav-link" href="index.php">
                                <span class="nav-text">Home</span>
                                                            </a>
                        </li>
                                            <li class="nav-item">
                            <a class="nav-link" href="index.php#about">
                                <span class="nav-text">About</span>
                                                            </a>
                        </li>
                                            <li class="nav-item">
                            <a class="nav-link" href="index.php#process">
                                <span class="nav-text">Our Process</span>
                                                            </a>
                        </li>
                                            <li class="nav-item">
                            <a class="nav-link" href="partnership.php">
                                <span class="nav-text">Partnership</span>
                                                            </a>
                        </li>
                                            <li class="nav-item">
                            <a class="nav-link" href="leadership.php">
                                <span class="nav-text">Leadership</span>
                                                            </a>
                        </li>
                                            <li class="nav-item">
                            <a class="nav-link" href="index.php#contact">
                                <span class="nav-text">Contact</span>
                                                                    <i class="fas fa-envelope nav-icon d-lg-none"></i>
                                                            </a>
                        </li>
                                    </ul>
            </div>
        </div>
    </nav>
</header>    
    <!-- Hero Section -->
    <section class="partnership-hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8 mx-auto text-center">
                    <div class="urgency-badge">
                        <i class="fas fa-clock"></i>
                        <span>Urgent Partnership Opportunity</span>
                    </div>
                   
                    <p class="hero-subtitle">
                        Join us in transforming traditional gold extraction through sustainable technology. 
                        Your partnership will empower local miners and revolutionize artisanal mining in Lubumbashi.
                    </p>
                    <div class="hero-buttons">
                        <a href="#partnership-form" class="btn btn-primary btn-lg me-3">
                            <i class="fas fa-handshake me-2"></i>Become a Partner
                        </a>
                        <a href="#solution" class="btn btn-outline-primary btn-lg">
                            <i class="fas fa-lightbulb me-2"></i>Learn About the Solution
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    

    <!-- Solution Section -->
<section class="solution-section" id="solution">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto text-center">
                <h2 class="section-title">Partnership Benefits</h2>
                <p class="section-subtitle">
                    Gain first priority in receiving gold directly from our operations.
                    Become our number one preferred buyer, ensuring consistent and reliable supply.
                </p>
            </div>
        </div>
        
        <div class="solution-grid">
            <div class="solution-card">
                <div class="solution-icon">
                    <i class="fas fa-tools"></i>
                </div>
                <h4>Supply of High-Quality Equipment</h4>
                <p>Access to modern mining equipment and technology that enhances production efficiency and gold recovery rates. Partner with us to upgrade our operations with state-of-the-art machinery.</p>
                <div class="benefit-badge">
                    <i class="fas fa-check-circle"></i>
                    <span>Enhanced Production Capacity</span>
                </div>
            </div>
            
            <div class="solution-card">
                <div class="solution-icon">
                    <i class="fas fa-hand-holding-usd"></i>
                </div>
                <h4>Advance Payments & Incentives</h4>
                <p>Enjoy exclusive rewards for your timely payments. We appreciate your commitment with special gold incentives and priority access to our highest quality production batches.</p>
                <div class="benefit-badge">
                    <i class="fas fa-gem"></i>
                    <span>Premium Gold Incentives</span>
                </div>
            </div>
            
            <div class="solution-card">
                <div class="solution-icon">
                    <i class="fas fa-landmark"></i>
                </div>
                <h4>Government Royalties Management</h4>
                <p>Eliminate the burden of handling government royalty payments. When you partner with us, the community manages all required royalties on your behalf, and you receive a fair percentage share as part of the partnership benefit.</p>
                <div class="benefit-badge">
                    <i class="fas fa-file-contract"></i>
                    <span>Compliance Handled</span>
                </div>
            </div>
        </div>

        <!-- Additional Partnership Perks -->
        <div class="row mt-5">
            <div class="col-12">
                <div class="partnership-perks">
                    <h3 class="text-center mb-4">Additional Partnership Advantages</h3>
                    <div class="row">
                        <div class="col-md-4 perk-item">
                            <div class="perk-icon">
                                <i class="fas fa-star"></i>
                            </div>
                            <h5>Priority Access</h5>
                            <p>First refusal on all gold production before market release</p>
                        </div>
                        <div class="col-md-4 perk-item">
                            <div class="perk-icon">
                                <i class="fas fa-chart-line"></i>
                            </div>
                            <h5>Volume Discounts</h5>
                            <p>Competitive pricing for bulk purchases and long-term commitments</p>
                        </div>
                        <div class="col-md-4 perk-item">
                            <div class="perk-icon">
                                <i class="fas fa-shield-alt"></i>
                            </div>
                            <h5>Supply Security</h5>
                            <p>Guaranteed consistent supply with transparent sourcing</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

    
    <!-- Footer -->
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lubumbashi Gold Miners</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* General Footer Styles */
        .footer {
            background-color: #2c3e50;
            color: #ecf0f1;
            margin-top: 50px;
        }
        
        .footer h5, .footer h6 {
            color: #f1c40f;
            margin-bottom: 15px;
        }
        
        .footer a {
            color: #ecf0f1;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer a:hover {
            color: #f1c40f;
        }
        
        .social-links a {
            display: inline-block;
            margin-right: 15px;
            font-size: 20px;
        }
        
        /* Custom Modal Styles */
        .disclaimer-modal .modal-content {
            background-color: #1a1a1a;
            color: white;
            border: 3px solid #f1c40f;
            border-radius: 10px;
        }
        
        .disclaimer-modal .modal-header {
            border-bottom: 0px solid #f1c40f;
            background-color: #2c3e50;
        }
        
        .disclaimer-modal .modal-title {
            color: #f1c40f;
            font-weight: bold;
        }
        
        .disclaimer-modal .btn-close {
            filter: invert(1);
        }
        
        .disclaimer-modal .modal-footer {
            border-top: 0px solid #f1c40f;
        }
        
        .disclaimer-modal .btn-primary {
            background-color: #f1c40f;
            border-color: #f1c40f;
            color: #2c3e50;
            font-weight: bold;
        }
        
        .disclaimer-modal .btn-primary:hover {
            background-color: #f39c12;
            border-color: #f39c12;
        }
        
        .disclaimer-modal .btn-secondary {
            background-color: #7f8c8d;
            border-color: #7f8c8d;
        }
        
        .disclaimer-modal .btn-secondary:hover {
            background-color: #95a5a6;
            border-color: #95a5a6;
        }
        
        /* WhatsApp Button Styles */
        .whatsapp-float {
            position: fixed;
            width: 60px;
            height: 60px;
            bottom: 40px;
            right: 40px;
            background-color: #25d366;
            color: #FFF;
            border-radius: 50px;
            text-align: center;
            font-size: 30px;
            box-shadow: 2px 2px 3px #999;
            z-index: 100;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            animation: pulse 2s infinite;
            cursor: pointer;
        }
        
        .whatsapp-float:hover {
            background-color: #128C7E;
            transform: scale(1.1);
            box-shadow: 3px 3px 10px rgba(0, 0, 0, 0.3);
        }
        
        @keyframes pulse {
            0% {
                box-shadow: 0 0 0 0 rgba(37, 211, 102, 0.7);
            }
            70% {
                box-shadow: 0 0 0 10px rgba(37, 211, 102, 0);
            }
            100% {
                box-shadow: 0 0 0 0 rgba(37, 211, 102, 0);
            }
        }
        
        /* Tooltip */
        .whatsapp-tooltip {
            position: absolute;
            right: 70px;
            bottom: 20px;
            background-color: #333;
            color: white;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 14px;
            opacity: 0;
            transition: opacity 0.3s;
            pointer-events: none;
            white-space: nowrap;
        }
        
        .whatsapp-float:hover .whatsapp-tooltip {
            opacity: 1;
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .whatsapp-float {
                width: 50px;
                height: 50px;
                bottom: 20px;
                right: 20px;
                font-size: 25px;
            }
            
            .whatsapp-tooltip {
                right: 60px;
                font-size: 12px;
            }
        }
        
        /* Custom styles for WhatsApp tracking */
        .whatsapp-tracked {
            background-color: #128C7E !important;
        }
        
        .whatsapp-tracked:after {
            content: '✓';
            position: absolute;
            top: -5px;
            right: -5px;
            background: #f1c40f;
            color: #2c3e50;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            font-size: 12px;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
</head>
<body>

    <!-- Your main content here -->

    <!-- Footer -->
    <footer class="footer py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <h5>Lubumbashi Gold Miners</h5>
                    <p>Committed to ethical mining practices and community development in the Democratic Republic of Congo.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-6 mb-4">
                    <h6>Quick Links</h6>
                    <ul class="list-unstyled">
                        <li><a href="#home">Home</a></li>
                        <li><a href="#about">About</a></li>
                        <li><a href="#process">Our Process</a></li>
                        <li><a href="#products">Products</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-6 mb-4">
                    <h6>Resources</h6>
                    <ul class="list-unstyled">
                        <li><a href="#">Certifications</a></li>
                        <li><a href="#">Sustainability Report</a></li>
                        <li><a href="#">Community Projects</a></li>
                        <li><a href="#">FAQs</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 mb-4">
                    <h6>Contact Information</h6>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-map-marker-alt"></i> Lubumbashi, DRC</li>
                        <li>
                            <a href="tel:+256746317422" style="text-decoration: none; color: inherit;">
                                <i class="fas fa-phone"></i> +256 746317422
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" onclick="trackWhatsAppClick('+254707043495')" class="whatsapp-contact">
                                <i class="fab fa-whatsapp"></i> +254 707043495
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" onclick="trackWhatsAppClick('+243906263852')" class="whatsapp-contact">
                                <i class="fab fa-whatsapp"></i> +243 906263852
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" onclick="trackWhatsAppClick('+243897295691')" class="whatsapp-contact">
                                <i class="fab fa-whatsapp"></i> +243 897295691
                            </a>
                        </li>
                        <li><i class="fas fa-envelope"></i> info@lubumbashigoldminers.com</li>
                    </ul>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-6">
                    <p>&copy; 2024 Lubumbashi Community Gold Miners. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <a href="#" data-bs-toggle="modal" data-bs-target="#disclaimerModal">Disclaimer</a> | 
                    <a href="#">Privacy Policy</a> | 
                    <a href="#">Terms of Service</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Disclaimer Modal -->
    <div class="modal fade disclaimer-modal" id="disclaimerModal" tabindex="-1" aria-labelledby="disclaimerModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="disclaimerModalLabel">
                        <i class="fas fa-exclamation-triangle me-2"></i>Important Disclaimer
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>To prevent scams and fraudulent activities, we strongly advise all foreign investors and gold buyers to conduct proper due diligence before engaging in any business involving gold from the Democratic Republic of Congo (DRC).</p>
                    
                    <p>Be cautious of individuals or groups claiming partnerships with Congolese communities, military generals, or government officials without official verification.</p>
                    
                    <p>Please note that the Head Chief of Lubumbashi serves as the Board Chairman for all Community Gold Miners in the DRC, and all legitimate community gold dealings are coordinated under this office.</p>
                    
                    <div class="alert alert-warning mt-3">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong>For verification or inquiries:</strong> Contact us via WhatsApp for official guidance and assistance.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <a href="javascript:void(0);" onclick="trackWhatsAppModalClick()" class="btn btn-primary">
                        <i class="fab fa-whatsapp me-2"></i>Contact via WhatsApp
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- WhatsApp Floating Button -->
    <div class="whatsapp-float" id="whatsappButton" onclick="trackWhatsAppFloatClick()">
        <i class="fab fa-whatsapp"></i>
        <span class="whatsapp-tooltip">Chat with us on WhatsApp</span>
    </div>

    <!-- Hidden tracking form -->
    <form id="whatsappTrackForm" method="POST" action="track-whatsapp.php" target="_blank" style="display: none;">
        <input type="hidden" name="phone_number" id="trackPhoneNumber" value="+243906263852">
        <input type="hidden" name="message" id="trackMessage" value="Hello Lubumbashi Community Gold Miners, I would like to get more information about your services">
        <input type="hidden" name="source" id="trackSource" value="floating_button">
        <input type="hidden" name="page_url" id="trackPageUrl" value="/partnership.php">
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Automatically show the disclaimer modal when the page loads
        document.addEventListener('DOMContentLoaded', function() {
            // Check if user has already accepted the disclaimer
            if (!localStorage.getItem('disclaimerAccepted')) {
                // Show the modal after a short delay
                setTimeout(function() {
                    var disclaimerModal = new bootstrap.Modal(document.getElementById('disclaimerModal'));
                    disclaimerModal.show();
                    
                    // Set a flag when modal is closed
                    document.getElementById('disclaimerModal').addEventListener('hidden.bs.modal', function () {
                        localStorage.setItem('disclaimerAccepted', 'true');
                    });
                }, 1000);
            }
            
            // Add click event to the disclaimer link in footer
            document.querySelector('a[data-bs-target="#disclaimerModal"]').addEventListener('click', function() {
                var disclaimerModal = new bootstrap.Modal(document.getElementById('disclaimerModal'));
                disclaimerModal.show();
            });
            
            // Initialize page URL for tracking
            document.getElementById('trackPageUrl').value = window.location.href;
            
            // Check if WhatsApp click was already tracked in this session
            if (sessionStorage.getItem('whatsappClicked')) {
                document.getElementById('whatsappButton').classList.add('whatsapp-tracked');
            }
        });

        // Function to track WhatsApp clicks from floating button
        function trackWhatsAppFloatClick() {
            trackWhatsAppClick('+243906263852', 'Hello Lubumbashi Community Gold Miners, I would like to get more information about your services', 'floating_button');
        }

        // Function to track WhatsApp clicks from modal button
        function trackWhatsAppModalClick() {
            trackWhatsAppClick('+243906263852', 'Hello Lubumbashi Community Gold Miners, I would like to verify and get more information about your services', 'modal_button');
        }

        // Function to track WhatsApp clicks from contact numbers
        function trackWhatsAppClick(phoneNumber, message = '', source = 'contact_number') {
            // Default message if not provided
            if (!message) {
                message = 'Hello Lubumbashi Community Gold Miners, I would like to get more information about your services';
            }
            
            // Set tracking values
            document.getElementById('trackPhoneNumber').value = phoneNumber;
            document.getElementById('trackMessage').value = message;
            document.getElementById('trackSource').value = source;
            
            // Submit the tracking form
            document.getElementById('whatsappTrackForm').submit();
            
            // Open WhatsApp in a new tab (as backup)
            const whatsappUrl = `https://wa.me/${phoneNumber.replace('+', '')}?text=${encodeURIComponent(message)}`;
            window.open(whatsappUrl, '_blank');
            
            // Mark as tracked in this session
            sessionStorage.setItem('whatsappClicked', 'true');
            document.getElementById('whatsappButton').classList.add('whatsapp-tracked');
            
            // Send tracking data via AJAX
            sendWhatsAppTracking(phoneNumber, source, message);
            
            return false;
        }

        // Function to send WhatsApp tracking data via AJAX
        function sendWhatsAppTracking(phoneNumber, source, message) {
            const data = {
                phone_number: phoneNumber,
                source: source,
                message: message,
                page_url: window.location.href,
                user_agent: navigator.userAgent,
                timestamp: new Date().toISOString()
            };
            
            // Send tracking data
            fetch('ajax-track-whatsapp.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(data => {
                console.log('WhatsApp click tracked:', data);
            })
            .catch(error => {
                console.error('Tracking error:', error);
            });
        }

        // Function to track page views
        function trackPageView() {
            const data = {
                action: 'track_pageview',
                page_url: window.location.href,
                referrer: document.referrer
            };
            
            fetch('ajax-track-visitor.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(data => {
                console.log('Page view tracked:', data);
                if (data.visitor_id) {
                    localStorage.setItem('visitor_id', data.visitor_id);
                }
            })
            .catch(error => {
                console.error('Page tracking error:', error);
            });
        }

        // Track page view on load
        window.addEventListener('load', function() {
            // Only track if not already tracked in this session
            if (!sessionStorage.getItem('pageTracked')) {
                trackPageView();
                sessionStorage.setItem('pageTracked', 'true');
            }
        });
    </script>
</body>
</html>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.js"></script>
    
    <script>
        // Partnership form handling
        document.addEventListener('DOMContentLoaded', function() {
            const partnershipForm = document.getElementById('partnershipInterestForm');
            
            if (partnershipForm) {
                partnershipForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    // Show loading state
                    const submitBtn = this.querySelector('button[type="submit"]');
                    const originalText = submitBtn.innerHTML;
                    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Submitting...';
                    submitBtn.disabled = true;
                    
                    // Simulate form submission
                    setTimeout(() => {
                        alert('Thank you for your partnership interest! We will contact you within 48 hours to discuss this opportunity.');
                        partnershipForm.reset();
                        submitBtn.innerHTML = originalText;
                        submitBtn.disabled = false;
                    }, 2000);
                });
            }
            
            // Smooth scrolling for anchor links
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    const target = document.querySelector(this.getAttribute('href'));
                    if (target) {
                        target.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                });
            });
        });
    </script>
</body>
</html>