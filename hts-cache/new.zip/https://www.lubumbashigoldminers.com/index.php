
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
      
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Primary Meta Tags -->
    <title>Lubumbashi Gold Miners | Gold Mining, Buying, Selling, Testing & Partnership Services DRC</title>
    <meta name="description" content="Lubumbashi Gold Miners: Complete gold services in DRC. Gold mining operations, buying raw gold, selling refined gold, XRF testing, assaying, mining partnerships, joint ventures, and community development. Ethical & sustainable practices.">
    <meta name="keywords" content="gold mining DRC, gold buying Congo, gold selling services, gold testing, XRF analyzer, gold assaying, mining partnerships, joint ventures, artisanal mining, gold exploration, mine development, gold processing, gold refining, sustainable mining, ethical gold, community mining, DRC gold, Congo minerals, mining investment, gold export, mineral rights, mining consultancy">
    <meta name="author" content="Lubumbashi Gold Miners">
    <meta name="robots" content="index, follow">

    <!-- Geographic Meta Tags -->
    <meta name="geo.region" content="CD-LU">
    <meta name="geo.placename" content="Lubumbashi">
    <meta name="geo.position" content="-11.664231;27.482626">
    <meta name="ICBM" content="-11.664231, 27.482626">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://lubumbashigoldminers.com/">
    <meta property="og:title" content="Lubumbashi Gold Miners | Complete Gold Mining & Trading Services">
    <meta property="og:description" content="DRC's premier gold services: Mining operations, gold trading, XRF testing, mining partnerships & joint ventures. Ethical practices with community empowerment.">
    <meta property="og:image" content="https://lubumbashigoldminers.com/assets/images/og-image.jpg">
    <meta property="og:image:alt" content="Lubumbashi Gold Miners - Gold Mining & Partnership Services">
    <meta property="og:site_name" content="Lubumbashi Gold Miners">
    <meta property="og:locale" content="en_US">

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="https://lubumbashigoldminers.com/">
    <meta property="twitter:title" content="Lubumbashi Gold Miners | Mining & Gold Services Experts">
    <meta property="twitter:description" content="Professional gold mining, trading, testing & partnership services in DRC. XRF testing, fair trade, and sustainable mining practices.">
    <meta property="twitter:image" content="https://lubumbashigoldminers.com/assets/images/og-image.jpg">

    <!-- Canonical URL -->
    <link rel="canonical" href="https://lubumbashigoldminers.com/">

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="favicon.png">

    <!-- Additional Icons -->
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">

    <!-- Preload Critical Resources -->
    <link rel="preload" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" as="style">
    <link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" as="style">
    <link rel="preload" href="assets/css/style.css" as="style">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- Language Alternates -->
    <link rel="alternate" hreflang="fr" href="https://lubumbashigoldminers.com/fr/" />
    <link rel="alternate" hreflang="sw" href="https://lubumbashigoldminers.com/sw/" />
    <link rel="alternate" hreflang="en" href="https://lubumbashigoldminers.com/" />

    <!-- Mobile Optimization -->
    <meta name="format-detection" content="telephone=no">
    <meta name="HandheldFriendly" content="true">
    <meta name="MobileOptimized" content="width">

    <!-- Additional SEO Meta Tags -->
    <meta name="subject" content="Gold Mining, Trading, Testing & Partnership Services in Democratic Republic of Congo">
    <meta name="classification" content="Precious Metals, Mining Services, Gold Trading, Mining Partnerships">
    <meta name="reply-to" content="contact@lubumbashigoldminers.com">
    <meta name="directory" content="submission">
    <meta name="category" content="Business">
    <meta name="coverage" content="Worldwide">
    <meta name="distribution" content="Global">
    <meta name="rating" content="General">
    <meta name="revisit-after" content="7 days">

    <!-- Comprehensive Structured Data -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "Organization",
          "@id": "https://lubumbashigoldminers.com/#organization",
          "name": "Lubumbashi Gold Miners",
          "url": "https://lubumbashigoldminers.com/",
          "logo": "https://lubumbashigoldminers.com/assets/images/logo.png",
          "description": "Complete gold mining, trading, testing and partnership services in Democratic Republic of Congo",
          "foundingDate": "2010",
          "numberOfEmployees": "50-100",
          "slogan": "Ethical Gold Mining & Sustainable Community Development",
          "address": {
            "@type": "PostalAddress",
            "streetAddress": "Lubumbashi Mining District",
            "addressLocality": "Lubumbashi",
            "addressRegion": "Haut-Katanga",
            "postalCode": "DRC001",
            "addressCountry": "CD"
          },
          "contactPoint": {
            "@type": "ContactPoint",
            "telephone": "+243 897295691",
            "contactType": "customer service",
            "email": "contact@lubumbashigoldminers.com",
            "areaServed": "CD",
            "availableLanguage": ["en", "fr", "sw"]
          },
          "sameAs": [
            "https://www.facebook.com/lubumbashigoldminers",
            "https://www.linkedin.com/company/lubumbashi-gold-miners",
            "https://twitter.com/lubumbashigold"
          ]
        },
        {
          "@type": "WebSite",
          "@id": "https://lubumbashigoldminers.com/#website",
          "url": "https://lubumbashigoldminers.com/",
          "name": "Lubumbashi Gold Miners",
          "description": "Professional gold services in DRC - Mining, Trading, Testing & Partnerships",
          "publisher": {
            "@id": "https://lubumbashigoldminers.com/#organization"
          },
          "inLanguage": "en"
        },
        {
          "@type": "LocalBusiness",
          "@id": "https://lubumbashigoldminers.com/#localbusiness",
          "name": "Lubumbashi Gold Miners",
          "image": "https://lubumbashigoldminers.com/assets/images/business-image.jpg",
          "url": "https://lubumbashigoldminers.com/",
          "telephone": "+243 897295691",
          "priceRange": "$$$",
          "address": {
            "@type": "PostalAddress",
            "streetAddress": "Lubumbashi Mining District",
            "addressLocality": "Lubumbashi",
            "addressRegion": "Haut-Katanga",
            "postalCode": "DRC001",
            "addressCountry": "CD"
          },
          "geo": {
            "@type": "GeoCoordinates",
            "latitude": -11.664231,
            "longitude": 27.482626
          },
          "openingHoursSpecification": {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": [
              "Monday",
              "Tuesday",
              "Wednesday",
              "Thursday",
              "Friday",
              "Saturday"
            ],
            "opens": "08:00",
            "closes": "18:00"
          },
          "areaServed": {
            "@type": "GeoCircle",
            "geoMidpoint": {
              "@type": "GeoCoordinates",
              "latitude": -11.664231,
              "longitude": 27.482626
            },
            "geoRadius": "500000"
          }
        }
      ]
    }
    </script>

    <!-- Services Structured Data -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "ItemList",
      "name": "Gold Mining & Trading Services",
      "description": "Complete range of gold services offered by Lubumbashi Gold Miners",
      "numberOfItems": 8,
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "item": {
            "@type": "Service",
            "name": "Gold Mining Operations",
            "description": "Professional gold mining operations with modern equipment and sustainable practices",
            "provider": {
              "@type": "Organization",
              "name": "Lubumbashi Gold Miners"
            },
            "areaServed": "Democratic Republic of Congo"
          }
        },
        {
          "@type": "ListItem",
          "position": 2,
          "item": {
            "@type": "Service",
            "name": "Gold Buying Services",
            "description": "Purchase raw gold from artisanal miners at fair market prices with transparent valuation",
            "provider": {
              "@type": "Organization",
              "name": "Lubumbashi Gold Miners"
            }
          }
        },
        {
          "@type": "ListItem",
          "position": 3,
          "item": {
            "@type": "Service",
            "name": "Gold Selling & Export",
            "description": "Sell refined and certified gold to international markets and local buyers",
            "provider": {
              "@type": "Organization",
              "name": "Lubumbashi Gold Miners"
            }
          }
        },
        {
          "@type": "ListItem",
          "position": 4,
          "item": {
            "@type": "Service",
            "name": "Gold Testing & Assaying",
            "description": "Professional gold purity testing using XRF analyzers and traditional fire assaying methods",
            "provider": {
              "@type": "Organization",
              "name": "Lubumbashi Gold Miners"
            }
          }
        },
        {
          "@type": "ListItem",
          "position": 5,
          "item": {
            "@type": "Service",
            "name": "Mining Partnerships",
            "description": "Strategic partnerships for joint mining ventures and collaborative projects",
            "provider": {
              "@type": "Organization",
              "name": "Lubumbashi Gold Miners"
            }
          }
        },
        {
          "@type": "ListItem",
          "position": 6,
          "item": {
            "@type": "Service",
            "name": "Joint Ventures",
            "description": "Equity partnerships and joint venture opportunities in gold mining projects",
            "provider": {
              "@type": "Organization",
              "name": "Lubumbashi Gold Miners"
            }
          }
        },
        {
          "@type": "ListItem",
          "position": 7,
          "item": {
            "@type": "Service",
            "name": "Mining Consultancy",
            "description": "Expert mining consultancy services including exploration and mine development",
            "provider": {
              "@type": "Organization",
              "name": "Lubumbashi Gold Miners"
            }
          }
        },
        {
          "@type": "ListItem",
          "position": 8,
          "item": {
            "@type": "Service",
            "name": "Community Mining Development",
            "description": "Support for artisanal miners and community-based mining initiatives",
            "provider": {
              "@type": "Organization",
              "name": "Lubumbashi Gold Miners"
            }
          }
        }
      ]
    }
    </script>

    <!-- Analytics / Metrics -->
    <script defer src="https://shown.io/metrics/vg8VlMxz0k" type="text/javascript"></script>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2794078128461810" crossorigin="anonymous"></script>
</head>

<body>
<header>
    <nav class="navbar navbar-expand-lg navbar-light fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#home">
                <img src="assets/images/logo.png" alt="Lubumbashi Gold Miners" height="50" class="brand-logo">
                <span class="brand-text-full">LUBUMBASHI GOLD MINERS</span>
                <span class="brand-text-short">LUBUMBASHI GOLD...</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                                            <li class="nav-item">
                            <a class="nav-link" href="#home">
                                <span class="nav-text">Home</span>
                                                            </a>
                        </li>
                                            <li class="nav-item">
                            <a class="nav-link" href="#about">
                                <span class="nav-text">About</span>
                                                            </a>
                        </li>
                                            <li class="nav-item">
                            <a class="nav-link" href="#process">
                                <span class="nav-text">Our Process</span>
                                                            </a>
                        </li>
                                            <li class="nav-item">
                            <a class="nav-link" href="#leadership">
                                <span class="nav-text">Leadership</span>
                                                            </a>
                        </li>
                                            <li class="nav-item">
                            <a class="nav-link" href="partnership.php">
                                <span class="nav-text">Partnership</span>
                                                            </a>
                        </li>
                                            <li class="nav-item">
                            <a class="nav-link" href="#contact">
                                <span class="nav-text">Contact</span>
                                                                    <i class="fas fa-envelope nav-icon d-lg-none"></i>
                                                            </a>
                        </li>
                                    </ul>
            </div>
        </div>
    </nav>
</header>    <style>
    /* Modern Contact Section */
.contact-info-section {
    padding: 3rem 0;
    background: linear-gradient(135deg, #f8fafc 0%, #ffffff 100%);
}

.contact-info-card {
    background: white;
    padding: 3rem;
    border-radius: 24px;
    box-shadow: 
        0 10px 40px rgba(0, 0, 0, 0.08),
        0 1px 2px rgba(0, 0, 0, 0.03);
    border: 1px solid rgba(255, 215, 0, 0.15);
    backdrop-filter: blur(10px);
    position: relative;
    overflow: hidden;
}

.contact-info-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, 
        var(--primary-color), 
        var(--secondary-color), 
        var(--accent-color));
    border-radius: 24px 24px 0 0;
}

.contact-heading {
    color: var(--dark-color);
    font-weight: 700;
    font-size: 2.2rem;
    margin-bottom: 1rem;
    background: linear-gradient(135deg, var(--dark-color), #2c3e50);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.contact-description {
    color: #64748b;
    font-size: 1.1rem;
    line-height: 1.6;
    margin-bottom: 3rem !important;
}

/* Contact Items Grid */
.contact-info-item {
    padding: 2rem 1.5rem;
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    height: 100%;
    border-radius: 16px;
    background: #ffffff;
    border: 1px solid #f1f5f9;
    position: relative;
    overflow: hidden;
}

.contact-info-item::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, 
        transparent, 
        rgba(255, 215, 0, 0.05), 
        transparent);
    transition: left 0.6s ease;
}

.contact-info-item:hover::before {
    left: 100%;
}

.contact-info-item:hover {
    transform: translateY(-8px);
    box-shadow: 
        0 20px 40px rgba(0, 0, 0, 0.12),
        0 8px 16px rgba(255, 215, 0, 0.1);
    border-color: rgba(255, 215, 0, 0.3);
}

.contact-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, #ffffff, #f8fafc);
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 1.5rem;
    color: var(--primary-color);
    font-size: 1.8rem;
    transition: all 0.4s ease;
    position: relative;
    border: 2px solid #f1f5f9;
    box-shadow: 0 4px 12px rgba(255, 215, 0, 0.15);
}

.contact-icon::after {
    content: '';
    position: absolute;
    top: -2px;
    left: -2px;
    right: -2px;
    bottom: -2px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-radius: 20px;
    opacity: 0;
    transition: opacity 0.3s ease;
    z-index: -1;
}

.contact-info-item:hover .contact-icon {
    transform: scale(1.1) rotate(5deg);
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: white;
    border-color: transparent;
    box-shadow: 0 8px 25px rgba(255, 107, 53, 0.3);
}

.contact-info-item:hover .contact-icon::after {
    opacity: 1;
}

.contact-text h5 {
    color: var(--dark-color);
    font-weight: 700;
    margin-bottom: 1rem;
    font-size: 1.2rem;
    position: relative;
    display: inline-block;
}

.contact-text h5::after {
    content: '';
    position: absolute;
    bottom: -4px;
    left: 0;
    width: 0;
    height: 2px;
    background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
    transition: width 0.3s ease;
}

.contact-info-item:hover .contact-text h5::after {
    width: 100%;
}

.contact-text p {
    color: #64748b;
    line-height: 1.6;
    margin: 0;
    font-size: 0.95rem;
    transition: color 0.3s ease;
}

.contact-info-item:hover .contact-text p {
    color: #475569;
}

/* Modern Social Contact Section */
.social-contact {
    background: linear-gradient(135deg, #ffffff, #f8fafc);
    padding: 2.5rem;
    border-radius: 20px;
    margin-top: 3rem;
    border: 1px solid #f1f5f9;
    position: relative;
    overflow: hidden;
}

.social-contact::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: linear-gradient(90deg, 
        var(--primary-color), 
        var(--secondary-color), 
        var(--accent-color));
}

.social-contact h5 {
    color: var(--dark-color);
    font-weight: 700;
    font-size: 1.3rem;
    margin-bottom: 1.5rem;
    text-transform: uppercase;
    letter-spacing: 1px;
    position: relative;
    display: inline-block;
}

.social-contact h5::after {
    content: '';
    position: absolute;
    bottom: -8px;
    left: 50%;
    transform: translateX(-50%);
    width: 40px;
    height: 3px;
    background: var(--primary-color);
    border-radius: 2px;
}

.social-links {
    display: flex;
    gap: 1rem;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;
}

.social-link {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, #ffffff, #f8fafc);
    color: var(--dark-color);
    border-radius: 14px;
    display: inline-flex;
    justify-content: center;
    align-items: center;
    font-size: 1.2rem;
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    text-decoration: none;
    border: 1px solid #e2e8f0;
    position: relative;
    overflow: hidden;
}

.social-link::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    opacity: 0;
    transition: opacity 0.3s ease;
    border-radius: 13px;
}

.social-link i {
    position: relative;
    z-index: 2;
    transition: all 0.3s ease;
}

.social-link:hover {
    transform: translateY(-5px) scale(1.1);
    border-color: transparent;
    box-shadow: 0 10px 25px rgba(255, 215, 0, 0.3);
}

.social-link:hover::before {
    opacity: 1;
}

.social-link:hover i {
    color: white;
    transform: scale(1.1);
}

/* Specific colors for social platforms */
.social-link:nth-child(1):hover { box-shadow: 0 10px 25px rgba(59, 89, 152, 0.3); }
.social-link:nth-child(2):hover { box-shadow: 0 10px 25px rgba(29, 161, 242, 0.3); }
.social-link:nth-child(3):hover { box-shadow: 0 10px 25px rgba(0, 119, 181, 0.3); }
.social-link:nth-child(4):hover { box-shadow: 0 10px 25px rgba(225, 48, 108, 0.3); }

/* Responsive Design */
@media (max-width: 768px) {
    .contact-info-card {
        padding: 2.5rem 2rem;
        border-radius: 20px;
    }
    
    .contact-heading {
        font-size: 1.8rem;
    }
    
    .contact-info-item {
        padding: 1.5rem 1rem;
        margin-bottom: 1rem;
    }
    
    .contact-icon {
        width: 65px;
        height: 65px;
        font-size: 1.5rem;
        border-radius: 16px;
    }
    
    .contact-text h5 {
        font-size: 1.1rem;
    }
    
    .social-contact {
        padding: 2rem 1.5rem;
        margin-top: 2rem;
    }
    
    .social-link {
        width: 45px;
        height: 45px;
        font-size: 1.1rem;
        border-radius: 12px;
    }
}

@media (max-width: 576px) {
    .contact-info-section {
        padding: 2rem 0;
    }
    
    .contact-info-card {
        padding: 2rem 1.5rem;
        border-radius: 18px;
    }
    
    .contact-heading {
        font-size: 1.6rem;
    }
    
    .contact-description {
        font-size: 1rem;
        margin-bottom: 2rem !important;
    }
    
    .contact-info-item {
        padding: 1.25rem 0.75rem;
        border-radius: 14px;
    }
    
    .contact-icon {
        width: 55px;
        height: 55px;
        font-size: 1.3rem;
        border-radius: 14px;
    }
    
    .contact-text h5 {
        font-size: 1rem;
    }
    
    .contact-text p {
        font-size: 0.85rem;
    }
    
    .social-contact {
        padding: 1.5rem 1rem;
        border-radius: 16px;
    }
    
    .social-links {
        gap: 0.75rem;
    }
    
    .social-link {
        width: 40px;
        height: 40px;
        font-size: 1rem;
        border-radius: 10px;
    }
}

@media (max-width: 400px) {
    .contact-info-card {
        padding: 1.5rem 1rem;
    }
    
    .contact-info-item {
        padding: 1rem 0.5rem;
    }
    
    .contact-icon {
        width: 50px;
        height: 50px;
        font-size: 1.2rem;
    }
    
    .social-links {
        gap: 0.5rem;
    }
    
    .social-link {
        width: 38px;
        height: 38px;
        font-size: 0.9rem;
    }
}

/* Animation enhancements */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.contact-info-item {
    animation: fadeInUp 0.6s ease forwards;
    opacity: 0;
}

.contact-info-item:nth-child(1) { animation-delay: 0.1s; }
.contact-info-item:nth-child(2) { animation-delay: 0.2s; }
.contact-info-item:nth-child(3) { animation-delay: 0.3s; }
.contact-info-item:nth-child(4) { animation-delay: 0.4s; }

.social-link {
    animation: fadeInUp 0.6s ease forwards;
    opacity: 0;
}

.social-link:nth-child(1) { animation-delay: 0.5s; }
.social-link:nth-child(2) { animation-delay: 0.6s; }
.social-link:nth-child(3) { animation-delay: 0.7s; }
.social-link:nth-child(4) { animation-delay: 0.8s; }
</style>
<main>
    <!-- Hero Carousel Section -->
    <section id="home" class="hero-section">
        <div id="heroCarousel" class="carousel slide" data-bs-ride="carousel" data-bs-interval="5000">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="0" class="active"></button>
                <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="1"></button>
                <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="2"></button>
                <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="3"></button>
                <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="4"></button>
                

            </div>
            
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="assets/images/slide1.jpg" class="d-block w-100" alt="Mining Operation">
                    
                </div>

                <div class="carousel-item">
                    <img src="assets/images/slide3.jpg" class="d-block w-100" alt="Gold Products">
                    
                </div>
                
                 <div class="carousel-item">
                    <img src="assets/images/slide6.jpg" class="d-block w-100" alt="Gold Products">
                    
                </div>
                 <div class="carousel-item">
                    <img src="assets/images/slide7.jpg" class="d-block w-100" alt="Gold Products">
                    
                </div>
                 <div class="carousel-item">
                    <img src="assets/images/slide8.jpg" class="d-block w-100" alt="Gold Products">
                    
                </div>
            </div>
            
            <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </section>

    
    <!-- About Section -->
     <!-- About Section with Video -->
<section id="about" class="about-section py-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h2 class="section-title">About Us</h2>
                <p>
                    Lubumbashi Gold Miners also known as Lubumbashi Community Gold Miners is a village association of local gold miners in the Lubumbashi Community. Guided by the Head Chief of the Lubumbashi, the association operates with integrity, transparency, and a deep commitment to responsible mining practices.
                    We are dedicated to promoting ethical gold mining and fair trade by ensuring that all our members and partners are recognized and endorsed by the local community. Our mission is to protect genuine miners and gold dealers from fraudulent activities and unethical practices by collaborating exclusively with trusted, certified gold refineries and smelters across the region.
                    At Lubumbashi Community Gold Miners, we take pride in fostering trust, sustainability, and community empowerment ensuring that the wealth of our land benefits our people and future generations                     
                                        
                </p>
                <ul class="about-features">
                    <li><i class="fas fa-check"></i> Over 15 years of mining experience</li>
                    <li><i class="fas fa-check"></i> 500+ community members employed</li>
                    <li><i class="fas fa-check"></i> Environmentally responsible practices</li>
                    <li><i class="fas fa-check"></i> Fair trade certified operations</li>
                </ul>
                
               
            </div>
            
            <div class="col-lg-6">
                <div class="about-video-container">
                    <video class="about-video" autoplay muted loop playsinline poster="assets/videos/posters/video2.png">
                        <source src="assets/videos/about.mov" type="video/mp4">
                        <source src="assets/videos/about.webm" type="video/webm">
                        Your browser does not support the video tag.
                    </video>
                    <div class="video-overlay-content">
                        <div class="play-indicator">
                            <i class="fas fa-play"></i>
                        </div>
                        <p>Watch Our Story</p>
                    </div>
                    <div class="video-controls">
                        <button class="control-btn play-pause-btn">
                            <i class="fas fa-play"></i>
                        </button>
                        <button class="control-btn mute-btn">
                            <i class="fas fa-volume-up"></i>
                        </button>
                        <div class="video-progress">
                            <div class="progress-bar"></div>
                        </div>
                    </div>
                    <div class="video-caption">
                        <i class="fas fa-info-circle"></i>
                        <span>Our commitment to ethical mining in Lubumbashi</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
/* About Section Video Container */
.about-video-container {
    position: relative;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
    background: var(--dark-color);
    transition: all 0.3s ease;
}

.about-video-container:hover {
    transform: translateY(-5px);
    box-shadow: 0 20px 50px rgba(0, 0, 0, 0.3);
}

.about-video {
    width: 100%;
    height: 400px;
    object-fit: cover;
    display: block;
    transition: all 0.3s ease;
}

.about-video-container:hover .about-video {
    transform: scale(1.02);
}

.video-overlay-content {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, rgba(44, 62, 80, 0.7), rgba(255, 107, 53, 0.3));
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: white;
    opacity: 0;
    transition: all 0.3s ease;
    pointer-events: none;
}

.about-video-container:hover .video-overlay-content {
    opacity: 1;
}

.play-indicator {
    width: 70px;
    height: 70px;
    background: linear-gradient(135deg, var(--primary-color), #ffed4e);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 1rem;
    font-size: 1.5rem;
    color: var(--dark-color);
    transition: all 0.3s ease;
}

.video-overlay-content p {
    font-size: 1.1rem;
    font-weight: 600;
    margin: 0;
    text-align: center;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
}

.video-controls {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background: linear-gradient(transparent, rgba(0, 0, 0, 0.8));
    padding: 1.5rem 1rem 1rem;
    display: flex;
    align-items: center;
    gap: 1rem;
    opacity: 0;
    transition: all 0.3s ease;
}

.about-video-container:hover .video-controls {
    opacity: 1;
}

.control-btn {
    width: 40px;
    height: 40px;
    background: rgba(255, 255, 255, 0.9);
    border: none;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--dark-color);
    font-size: 1rem;
    cursor: pointer;
    transition: all 0.3s ease;
}

.control-btn:hover {
    background: var(--primary-color);
    transform: scale(1.1);
}

.video-progress {
    flex: 1;
    height: 4px;
    background: rgba(255, 255, 255, 0.3);
    border-radius: 2px;
    overflow: hidden;
    cursor: pointer;
}

.progress-bar {
    height: 100%;
    background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
    width: 0%;
    transition: width 0.1s ease;
}

.video-caption {
    position: absolute;
    top: 1rem;
    left: 1rem;
    background: rgba(0, 0, 0, 0.7);
    color: white;
    padding: 0.5rem 1rem;
    border-radius: 25px;
    font-size: 0.9rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    backdrop-filter: blur(10px);
}

.video-caption i {
    color: var(--primary-color);
}

/* About Stats */
.about-stats {
    margin-top: 2rem;
}

.stat-item {
    padding: 1rem 0.5rem;
}

.stat-number {
    font-size: 2rem;
    font-weight: 800;
    color: var(--primary-color);
    line-height: 1;
    margin-bottom: 0.25rem;
    font-family: 'Arial', sans-serif;
}

.stat-label {
    font-size: 0.9rem;
    color: #666;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

/* About Features Enhancement */
.about-features {
    list-style: none;
    padding: 0;
    margin: 1.5rem 0;
}

.about-features li {
    padding: 0.75rem 0;
    font-size: 1.05rem;
    display: flex;
    align-items: center;
    transition: all 0.3s ease;
}

.about-features li:hover {
    transform: translateX(5px);
    color: var(--dark-color);
}

.about-features i {
    color: var(--success-color);
    margin-right: 1rem;
    font-size: 1.1rem;
    transition: all 0.3s ease;
}

.about-features li:hover i {
    transform: scale(1.2);
    color: var(--primary-color);
}

/* Responsive Design */
@media (max-width: 991.98px) {
    .about-video {
        height: 350px;
    }
    
    .play-indicator {
        width: 60px;
        height: 60px;
        font-size: 1.3rem;
    }
    
    .video-overlay-content p {
        font-size: 1rem;
    }
    
    .stat-number {
        font-size: 1.8rem;
    }
}

@media (max-width: 768px) {
    .about-video {
        height: 300px;
    }
    
    .about-video-container {
        margin-top: 2rem;
    }
    
    .play-indicator {
        width: 50px;
        height: 50px;
        font-size: 1.1rem;
    }
    
    .video-controls {
        padding: 1rem 0.75rem 0.75rem;
        gap: 0.75rem;
    }
    
    .control-btn {
        width: 35px;
        height: 35px;
        font-size: 0.9rem;
    }
    
    .video-caption {
        top: 0.75rem;
        left: 0.75rem;
        font-size: 0.8rem;
        padding: 0.4rem 0.8rem;
    }
    
    .stat-item {
        padding: 0.75rem 0.25rem;
    }
    
    .stat-number {
        font-size: 1.6rem;
    }
    
    .stat-label {
        font-size: 0.8rem;
    }
}

@media (max-width: 576px) {
    .about-video {
        height: 250px;
    }
    
    .play-indicator {
        width: 45px;
        height: 45px;
        font-size: 1rem;
        margin-bottom: 0.75rem;
    }
    
    .video-overlay-content p {
        font-size: 0.9rem;
    }
    
    .video-controls {
        padding: 0.75rem 0.5rem 0.5rem;
        gap: 0.5rem;
    }
    
    .control-btn {
        width: 30px;
        height: 30px;
        font-size: 0.8rem;
    }
    
    .video-caption {
        top: 0.5rem;
        left: 0.5rem;
        font-size: 0.75rem;
        padding: 0.3rem 0.6rem;
    }
    
    .about-features li {
        font-size: 1rem;
        padding: 0.5rem 0;
    }
}

/* Video Loading State */
.about-video-container.loading::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 50px;
    height: 50px;
    border: 3px solid rgba(255, 255, 255, 0.3);
    border-top: 3px solid var(--primary-color);
    border-radius: 50%;
    animation: spin 1s linear infinite;
    z-index: 10;
}

@keyframes spin {
    0% { transform: translate(-50%, -50%) rotate(0deg); }
    100% { transform: translate(-50%, -50%) rotate(360deg); }
}
</style>

<script>
// About Section Video Controls
document.addEventListener('DOMContentLoaded', function() {
    const aboutVideoContainer = document.querySelector('.about-video-container');
    const aboutVideo = document.querySelector('.about-video');
    const playPauseBtn = document.querySelector('.play-pause-btn');
    const muteBtn = document.querySelector('.mute-btn');
    const progressBar = document.querySelector('.progress-bar');
    const videoProgress = document.querySelector('.video-progress');
    
    if (aboutVideo && playPauseBtn) {
        // Play/Pause functionality
        playPauseBtn.addEventListener('click', function() {
            if (aboutVideo.paused) {
                aboutVideo.play();
                playPauseBtn.innerHTML = '<i class="fas fa-pause"></i>';
            } else {
                aboutVideo.pause();
                playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
            }
        });
        
        // Mute/Unmute functionality
        if (muteBtn) {
            muteBtn.addEventListener('click', function() {
                aboutVideo.muted = !aboutVideo.muted;
                muteBtn.innerHTML = aboutVideo.muted ? 
                    '<i class="fas fa-volume-mute"></i>' : 
                    '<i class="fas fa-volume-up"></i>';
            });
        }
        
        // Progress bar update
        aboutVideo.addEventListener('timeupdate', function() {
            if (progressBar) {
                const progress = (aboutVideo.currentTime / aboutVideo.duration) * 100;
                progressBar.style.width = progress + '%';
            }
        });
        
        // Click on progress bar to seek
        if (videoProgress) {
            videoProgress.addEventListener('click', function(e) {
                const rect = videoProgress.getBoundingClientRect();
                const pos = (e.clientX - rect.left) / rect.width;
                aboutVideo.currentTime = pos * aboutVideo.duration;
            });
        }
        
        // Video loading state
        aboutVideo.addEventListener('loadstart', function() {
            aboutVideoContainer.classList.add('loading');
        });
        
        aboutVideo.addEventListener('canplay', function() {
            aboutVideoContainer.classList.remove('loading');
        });
        
        // Handle video end
        aboutVideo.addEventListener('ended', function() {
            playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
            aboutVideo.currentTime = 0;
        });
        
        // Hover play indicator
        const playIndicator = document.querySelector('.play-indicator');
        if (playIndicator) {
            playIndicator.addEventListener('click', function() {
                aboutVideo.play();
                playPauseBtn.innerHTML = '<i class="fas fa-pause"></i>';
            });
        }
    }
});


</script>   <!-- Video Activities Section -->
    
    <style>
        /* Unique CSS variables to prevent conflicts */
        :root {
            --dr-primary-red: #8B0000;
            --dr-dark-red: #5a0000;
            --dr-light-red: #a83232;
            --dr-accent-color: #ffab00;
        }
        
      
        
        /* Unique disclaimer section styles */
        .dr-disclaimer-section {
            background: linear-gradient(135deg, var(--dr-primary-red) 0%, var(--dr-dark-red) 100%);
            position: relative;
            overflow: hidden;
            
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            margin: 10px 0;
        }
        
        .dr-disclaimer-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                radial-gradient(circle at 20% 80%, rgba(255,255,255,0.05) 0%, transparent 20%),
                radial-gradient(circle at 80% 20%, rgba(255,255,255,0.05) 0%, transparent 20%);
            z-index: 1;
        }
        
        .dr-disclaimer-section .container {
            position: relative;
            z-index: 2;
        }
        
        .dr-section-title {
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            position: relative;
            display: inline-block;
            margin-bottom: 2rem;
            color: #fff;
        }
        
        .dr-section-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background-color: var(--dr-accent-color);
            border-radius: 2px;
        }
        
        .dr-disclaimer-section p {
            font-size: 1.1rem;
            line-height: 1.4;
            margin-bottom: 1.0rem;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
            color: #fff;
        }
        
        .dr-alert-modern {
            background: rgba(255, 255, 255, 0.4);
            border: none;
            border-radius: 12px;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-left: 4px solid var(--dr-accent-color);
            padding: 1.2rem;
            margin-top: 2rem;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.6);
        }
        
        .dr-alert-modern i {
            color: var(--dr-accent-color);
            font-size: 1.3rem;
        }
        
        .dr-alert-modern strong {
            color: #fff;
            font-weight: 600;
        }
        
        .dr-contact-button {
            background-color: var(--dr-accent-color);
            color: #333;
            border: none;
            border-radius: 50px;
            padding: 12px 30px;
            font-weight: 600;
            margin-top: 1rem;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(255, 171, 0, 0.3);
        }
        
        .dr-contact-button:hover {
            background-color: #ffb300;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(255, 171, 0, 0.4);
        }
        
        .dr-warning-icon {
            font-size: 1.5rem;
            color: var(--dr-accent-color);
            margin-right: 10px;
        }
        
        .dr-card-modern {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: transform 0.3s ease;
        }
        
        .dr-card-modern:hover {
            transform: translateY(-5px);
        }
        
        .dr-card-title {
            font-weight: 600;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            color: #fff;
        }
    </style>
</head>
<body>
    <!-- Process Section -->
    <section class="dr-disclaimer-section py-4">
        <div class="container">
            <h2 class="dr-section-title mb-3">Disclaimer</h2>
            
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="dr-card-modern">
                        
                        <p>To prevent scams and fraudulent activities, we strongly advise all foreign investors and gold buyers to conduct proper due diligence before engaging in any business involving gold from the Democratic Republic of Congo (DRC).</p>
                   
                        
                        <p>Be cautious of individuals or groups claiming partnerships with Congolese communities, military generals, or government officials without official verification.</p>
                    
                      
                        <p>Please note that the Head Chief of Lubumbashi serves as the Board Chairman for all Community Gold Miners in the DRC, and all legitimate community gold dealings are coordinated under this office.</p>
                    </div>
                    
                    <div class="dr-alert-modern mt-4">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-info-circle me-3"></i>
                            <div>
                                <strong>All due diligence and consultations are completely <span class="highlight-text">free of charge</span>. </strong>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Activities Section with Read More -->
<section id="activities" class="video-activities-section py-5">
    <div class="container">
        <h2 class="section-title text-center mb-5">Our Activities</h2>
        <p class="section-subtitle text-center mb-5">Watch how we're making a difference through responsible mining and community development</p>
        
        <div class="row">
            <!-- Video 1: Responsible Mining -->
            <div class="col-lg-4 col-md-6 mb-5">
                <div class="video-card">
                    <div class="video-container">
                        <video class="activity-video" poster="assets/videos/posters/video1.jpg" preload="metadata">
                            <source src="assets/videos/video1.mov" type="video/mp4">
                            <source src="assets/videos/responsible-mining.webm" type="video/webm">
                            Your browser does not support the video tag.
                        </video>
                        <div class="video-overlay">
                            <button class="play-btn">
                                <i class="fas fa-play"></i>
                            </button>
                            <div class="video-duration">0:07</div>
                        </div>
                    </div>
                    <div class="video-content">
                        <div class="video-icon">
                            <i class="fa-solid fa-sun"></i>
                        </div>
                        <h4>Sun Drying Extracts: A Call for Sustainable Innovation</h4>
                        <p>
                            
                        Our community currently relies on traditional sun-drying methods to extract gold, a process passed down through generations. While it is cost-effective and environmentally friendly, this method has significant drawbacks:

                        </p>
                        <div class="video-stats">
                            <span class="stat">
                                <i class="fas fa-eye"></i> 1.2K views
                            </span>
                            <span class="stat">
                                <i class="far fa-calendar"></i> 2 weeks ago
                            </span>
                        </div>
                        <button class="read-more-btn" data-page="sundrying">
                            <span>Read More</span>
                            <i class="fas fa-arrow-right"></i>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Video 2: Environmental Protection -->
            <div class="col-lg-4 col-md-6 mb-5">
                <div class="video-card">
                    <div class="video-container">
                        <video class="activity-video" poster="assets/videos/posters/video2.jpg" preload="metadata">
                            <source src="assets/videos/video2.mov" type="video/mp4">
                            <source src="assets/videos/environmental-protection.webm" type="video/webm">
                            Your browser does not support the video tag.
                        </video>
                        <div class="video-overlay">
                            <button class="play-btn">
                                <i class="fas fa-play"></i>
                            </button>
                            <div class="video-duration">0:15</div>
                        </div>
                    </div>
                    <div class="video-content">
                        <div class="video-icon">
                            <i class="fa-solid fa-gears"></i>
                        </div>
                        <h4>Milling Machines: Enhancing Artisanal Gold Recovery</h4>
                        <p>
                            Milling machines play a vital role in breaking down hard rock during 
                            gold extraction. However, most artisanal miners in the Lubumbashi
                             community rely on <strong>old, manually operated or inefficient
                                 milling machines</strong>.
                                 
                        </p>
                      
                       
                        <div class="video-stats">
                            <span class="stat">
                            <i class="fas fa-eye"></i> 980 views
                            </span>
                            <span class="stat">
                            <i class="far fa-calendar"></i> 1 month ago
                            </span>
                        </div>
                        <button class="read-more-btn" data-page="machinery">
                            <span>Read More</span>
                            <i class="fas fa-arrow-right"></i>
                        </button>
                        </div>

                </div>
            </div>

           
            <!-- Video 4: Fair Trade Practices -->
            <div class="col-lg-4 col-md-6 mb-5">
                <div class="video-card">
                    <div class="video-container">
                        <video class="activity-video" poster="assets/videos/posters/video4.jpg" preload="metadata">
                            <source src="assets/videos/video4.mov" type="video/mp4">
                            <source src="assets/videos/fair-trade.webm" type="video/webm">
                            Your browser does not support the video tag.
                        </video>
                        <div class="video-overlay">
                            <button class="play-btn">
                                <i class="fas fa-play"></i>
                            </button>
                            <div class="video-duration">0:04</div>
                        </div>
                    </div>
                    <div class="video-content">
                        <div class="video-icon">
                            <i class="fas fa-hand-holding-usd"></i>
                        </div>
                        <h4>Rock Crushing</h4>

                        <p>
                             The Lubumbashi Community Gold Miners rely on <strong>locally hand-crafted milling and crushing machines</strong> to break down hard stones and rocks extracted from mining pits. This traditional method, though resourceful, is highly labor-intensive and often inefficient, yielding low output and inconsistent particle sizes for further gold recovery.
     
                        </p>
                        <div class="video-stats">
                            <span class="stat">
                                <i class="fas fa-eye"></i> 1.1K views
                            </span>
                            <span class="stat">
                                <i class="far fa-calendar"></i> 2 months ago
                            </span>
                        </div>
                        <button class="read-more-btn" data-page="rockcrushing">
                            <span>Read More</span>
                            <i class="fas fa-arrow-right"></i>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Video 5: Healthcare Support -->
            <div class="col-lg-4 col-md-6 mb-5">
                <div class="video-card">
                    <div class="video-container">
                        <video class="activity-video" poster="assets/videos/posters/escavator.jpg" preload="metadata">
                            <source src="assets/videos/video5.mov" type="video/mp4">
                            <source src="assets/videos/healthcare-support.webm" type="video/webm">
                            Your browser does not support the video tag.
                        </video>
                        <div class="video-overlay">
                            <button class="play-btn">
                                <i class="fas fa-play"></i>
                            </button>
                            <div class="video-duration">0:12</div>
                        </div>
                    </div>
                    <div class="video-content">
                        <div class="video-icon">
                            <i class="fas fa-person"></i>
                        </div>
                        <h4>Open Cast Mining</h4>
                        <p>Open Cast Mining is one of the most efficient and accessible methods used by Lubumbashi Community Gold Miners for gold extraction. This surface mining technique involves removing layers of soil and rock to expose the gold-bearing ore underneath.</p>
                        <div class="video-stats">
                            <span class="stat">
                                <i class="fas fa-eye"></i> 890 views
                            </span>
                            <span class="stat">
                                <i class="far fa-calendar"></i> 1 week ago
                            </span>
                        </div>
                        <button class="read-more-btn" data-page="opencast">
                            <span>Read More</span>
                            <i class="fas fa-arrow-right"></i>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Video 6: Sustainable Development -->
            <div class="col-lg-4 col-md-6 mb-5">
                <div class="video-card">
                    <div class="video-container">
                        <video class="activity-video" poster="assets/videos/posters/video7.jpg" preload="metadata">
                            <source src="assets/videos/video7.mp4" type="video/mp4">
                            <source src="assets/videos/sustainable-development.webm" type="video/webm">
                            Your browser does not support the video tag.
                        </video>
                        <div class="video-overlay">
                            <button class="play-btn">
                                <i class="fas fa-play"></i>
                            </button>
                            <div class="video-duration">0:13</div>
                        </div>
                    </div>
                    <div class="video-content">
                        <div class="video-icon">
                            <i class="fas fa-seedling"></i>
                        </div>
                        <h4>The "Z method" of gold mining</h4>
                        <p>The "Z Method" is a locally developed and highly adaptive gold extraction technique practiced by Lubumbashi Community Gold Miners. The name originates from the zigzag pattern followed during excavation, resembling the letter “Z.”</p>
                        <div class="video-stats">
                            <span class="stat">
                                <i class="fas fa-eye"></i> 1.3K views
                            </span>
                            <span class="stat">
                                <i class="far fa-calendar"></i> 2 weeks ago
                            </span>
                        </div>
                        <button class="read-more-btn" data-page="zmethod">
                            <span>Read More</span>
                            <i class="fas fa-arrow-right"></i>
                        </button>
                    </div>
                </div>
            </div>

            

            <!-- Video 6: Sustainable Development -->
            <div class="col-lg-4 col-md-6 mb-5">
                <div class="video-card">
                    <div class="video-container">
                        <video class="activity-video" poster="assets/videos/posters/golddore.jpeg" preload="metadata">
                            <source src="assets/videos/golddore.mp4" type="video/mp4">
                            <source src="assets/videos/sustainable-development.webm" type="video/webm">
                            Your browser does not support the video tag.
                        </video>
                        <div class="video-overlay">
                            <button class="play-btn">
                                <i class="fas fa-play"></i>
                            </button>
                            <div class="video-duration">0:13</div>
                        </div>
                    </div>
                    <div class="video-content">
                        <div class="video-icon">
                            <i class="fas fa-seedling"></i>
                        </div>
                        <h4>Gold Dore Bars</h4>
                        <p>
                        Gold Dore Bars are semi-pure bars produced after the initial smelting process. 
                        They contain a mix of gold and silver and are later refined further to achieve the highest purity standards before reaching the global market.
                        </p>

                        <div class="video-stats">
                            <span class="stat">
                                <i class="fas fa-eye"></i> 1.3K views
                            </span>
                            <span class="stat">
                                <i class="far fa-calendar"></i> 2 weeks ago
                            </span>
                        </div>
                        <button class="read-more-btn" data-page="zmethod">
                            <span>Read More</span>
                            <i class="fas fa-arrow-right"></i>
                        </button>
                    </div>
                </div>
            </div>

               <!-- Video 6: Sustainable Development -->
            <div class="col-lg-4 col-md-6 mb-5">
                <div class="video-card">
                    <div class="video-container">
                        <video class="activity-video" poster="assets/videos/posters/smelting.png" preload="metadata">
                            <source src="assets/videos/smelting.mp4" type="video/mp4">
                            <source src="assets/videos/sustainable-development.webm" type="video/webm">
                            Your browser does not support the video tag.
                        </video>
                        <div class="video-overlay">
                            <button class="play-btn">
                                <i class="fas fa-play"></i>
                            </button>
                            <div class="video-duration">0:13</div>
                        </div>
                    </div>
                    <div class="video-content">
                        <div class="video-icon">
                            <i class="fas fa-seedling"></i>
                        </div>
                        <h4>Smelting and Shaping</h4>
                        <p>
                        Smelting and shaping involve refining the raw gold extracted from the mines through high-temperature processing to remove impurities. 
                        The purified gold is then carefully molded and shaped into standardized forms such as bars, ingots, or ornaments, ensuring quality, purity, 
                        and compliance with international trade standards.
                        </p>

                        <div class="video-stats">
                            <span class="stat">
                                <i class="fas fa-eye"></i> 5.3K views
                            </span>
                            <span class="stat">
                                <i class="far fa-calendar"></i> 2 weeks ago
                            </span>
                        </div>
                       
                    </div>
                </div>
            </div>

               <!-- Video 6: Sustainable Development -->
            <div class="col-lg-4 col-md-6 mb-5">
                <div class="video-card">
                    <div class="video-container">
                        <video class="activity-video" poster="assets/videos/posters/wash.png" preload="metadata">
                            <source src="assets/videos/wash.mp4" type="video/mp4">
                            <source src="assets/videos/sustainable-development.webm" type="video/webm">
                            Your browser does not support the video tag.
                        </video>
                        <div class="video-overlay">
                            <button class="play-btn">
                                <i class="fas fa-play"></i>
                            </button>
                            <div class="video-duration">0:13</div>
                        </div>
                    </div>
                    <div class="video-content">
                        <div class="video-icon">
                            <i class="fas fa-seedling"></i>
                        </div>
                       <h4>Gold Washing</h4>
                        <p>
                        Gold washing is the process of thoroughly cleaning and purifying smelted gold to remove any remaining dirt, residue, or impurities. 
                        This step enhances the gold’s shine, quality, and overall appearance, preparing it for weighing, certification, and trade.
                        </p>
                        <div class="video-stats">
                            <span class="stat">
                                <i class="fas fa-eye"></i> 4.3K views
                            </span>
                            <span class="stat">
                                <i class="far fa-calendar"></i> 2 weeks ago
                            </span>
                        </div>
                       
                    </div>
                </div>
            </div>
       

                       <!-- Video 6: Sustainable Development -->
            <div class="col-lg-4 col-md-6 mb-5">
                <div class="video-card">
                    <div class="video-container">
                        <video class="activity-video" poster="assets/videos/posters/workers.jpg" preload="metadata">
                            <source src="assets/videos/workers.mp4" type="video/mp4">
                            <source src="assets/videos/sustainable-development.webm" type="video/webm">
                            Your browser does not support the video tag.
                        </video>
                        <div class="video-overlay">
                            <button class="play-btn">
                                <i class="fas fa-play"></i>
                            </button>
                            <div class="video-duration">0:13</div>
                        </div>
                    </div>
                    <div class="video-content">
                        <div class="video-icon">
                            <i class="fas fa-seedling"></i>
                        </div>
                       <h4>Miners Coming Out of the Mining Pit</h4>
                        <p>
                        After hours of intense work underground, miners emerge from the mining pit. 
                        This marks the completion of a crucial phase in the gold recovery process, reflecting the miners’ dedication, 
                        teamwork, and commitment to responsible and safe mining practices.
                        </p>

                        <div class="video-stats">
                            <span class="stat">
                                <i class="fas fa-eye"></i> 4.3K views
                            </span>
                            <span class="stat">
                                <i class="far fa-calendar"></i> 2 weeks ago
                            </span>
                        </div>
                       
                    </div>
                </div>
            </div>
      

                       <!-- Video 6: Sustainable Development -->
            <div class="col-lg-4 col-md-6 mb-5">
                <div class="video-card">
                    <div class="video-container">
                        <video class="activity-video" poster="assets/videos/posters/washprocess.png" preload="metadata">
                            <source src="assets/videos/washprocess.mp4" type="video/mp4">
                            <source src="assets/videos/sustainable-development.webm" type="video/webm">
                            Your browser does not support the video tag.
                        </video>
                        <div class="video-overlay">
                            <button class="play-btn">
                                <i class="fas fa-play"></i>
                            </button>
                            <div class="video-duration">0:13</div>
                        </div>
                    </div>
                    <div class="video-content">
                        <div class="video-icon">
                            <i class="fas fa-seedling"></i>
                        </div>
                       <h4>Washing Process</h4>
                       <p>
                        During the washing process, miners clean and separate gold-bearing materials from sand and gravel using water. 
                        This step helps to isolate heavier gold particles, ensuring that only pure and valuable minerals are collected for further processing.
                        </p>
                        <div class="video-stats">
                            <span class="stat">
                                <i class="fas fa-eye"></i> 4.3K views
                            </span>
                            <span class="stat">
                                <i class="far fa-calendar"></i> 2 weeks ago
                            </span>
                        </div>
                       
                    </div>
                </div>
            </div>
      


                       <!-- Video 6: Sustainable Development -->
            <div class="col-lg-4 col-md-6 mb-5">
                <div class="video-card">
                    <div class="video-container">
                        <video class="activity-video" poster="assets/videos/posters/transfering.jpg" preload="metadata">
                            <source src="assets/videos/transfering.mp4" type="video/mp4">
                            <source src="assets/videos/sustainable-development.webm" type="video/webm">
                            Your browser does not support the video tag.
                        </video>
                        <div class="video-overlay">
                            <button class="play-btn">
                                <i class="fas fa-play"></i>
                            </button>
                            <div class="video-duration">0:13</div>
                        </div>
                    </div>
                    <div class="video-content">
                        <div class="video-icon">
                            <i class="fas fa-seedling"></i>
                        </div>
                      <h4>Transferring Sand from the Mines</h4>
                        <p>
                        Miners carefully transfer sand and gravel from the mining pits to the washing or processing areas, 
                        where the material is sifted to extract gold particles. This step is crucial in separating valuable minerals 
                        from the surrounding soil and ensuring efficient recovery of gold.
                        </p>
                        <div class="video-stats">
                            <span class="stat">
                                <i class="fas fa-eye"></i> 4.3K views
                            </span>
                            <span class="stat">
                                <i class="far fa-calendar"></i> 2 weeks ago
                            </span>
                        </div>
                       
                    </div>
                </div>
            </div>
     


                   <!-- Video 6: Sustainable Development -->
            <div class="col-lg-4 col-md-6 mb-5">
                <div class="video-card">
                    <div class="video-container">
                        <video class="activity-video" poster="assets/videos/posters/pit.jpg" preload="metadata">
                            <source src="assets/videos/pit.mp4" type="video/mp4">
                            <source src="assets/videos/sustainable-development.webm" type="video/webm">
                            Your browser does not support the video tag.
                        </video>
                        <div class="video-overlay">
                            <button class="play-btn">
                                <i class="fas fa-play"></i>
                            </button>
                            <div class="video-duration">0:13</div>
                        </div>
                    </div>
                    <div class="video-content">
                        <div class="video-icon">
                            <i class="fas fa-seedling"></i>
                        </div>
                       <h4>Pit</h4>
                        <p>
                        The mining pit is the central excavation area where gold-bearing soil and rocks are carefully extracted. 
                        It serves as the primary source of raw material for gold processing, and its structure is maintained with strict 
                        safety and environmental standards to protect both miners and the surrounding ecosystem.
                        </p>

                        <div class="video-stats">
                            <span class="stat">
                                <i class="fas fa-eye"></i> 4.3K views
                            </span>
                            <span class="stat">
                                <i class="far fa-calendar"></i> 2 weeks ago
                            </span>
                        </div>
                       
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-5">
                <div class="video-card">
                    <div class="video-container">
                        <video class="activity-video" poster="assets/videos/posters/gold3.jpeg" preload="metadata">
                            <source src="assets/videos/strongroom.mp4" type="video/mp4">
                            <source src="assets/videos/sustainable-development.webm" type="video/webm">
                            Your browser does not support the video tag.
                        </video>
                        <div class="video-overlay">
                            <button class="play-btn">
                                <i class="fas fa-play"></i>
                            </button>
                            <div class="video-duration">0:13</div>
                        </div>
                    </div>
                    <div class="video-content">
                        <div class="video-icon">
                            <i class="fas fa-seedling"></i>
                        </div>
                       <h4>Gold in Strong Room</h4>
                        <p>
                        Our strong room securely stores all refined gold, ensuring maximum safety and protection. Equipped with advanced surveillance systems, access control, and 24-hour monitoring, the facility guarantees that every gold bar is safeguarded under strict security standards until official dispatch or client collection.

                        </p>

                        <div class="video-stats">
                            <span class="stat">
                                <i class="fas fa-eye"></i> 4.3K views
                            </span>
                            <span class="stat">
                                <i class="far fa-calendar"></i> 2 weeks ago
                            </span>
                        </div>
                       
                    </div>
                </div>
            </div>


            <div class="col-lg-4 col-md-6 mb-5">
                <div class="video-card">
                    <div class="video-container">
                        <video class="activity-video" poster="assets/videos/posters/testing.png" preload="metadata">
                            <source src="assets/videos/testing.mp4" type="video/mp4">
                            <source src="assets/videos/sustainable-development.webm" type="video/webm">
                            Your browser does not support the video tag.
                        </video>
                        <div class="video-overlay">
                            <button class="play-btn">
                                <i class="fas fa-play"></i>
                            </button>
                            <div class="video-duration">0:13</div>
                        </div>
                    </div>
                    <div class="video-content">
                        <div class="video-icon">
                            <i class="fas fa-seedling"></i>
                        </div>
                       <h4>Professional Gold Assaying & Testing</h4>
                        <p>
                        We have expert geologists and gold testers. For accurate and reliable results, we use advanced XRF (X-ray Fluorescence) gold testing machines to determine the exact purity and value of your gold.

                        </p>

                        <div class="video-stats">
                            <span class="stat">
                                <i class="fas fa-eye"></i> 4.3K views
                            </span>
                            <span class="stat">
                                <i class="far fa-calendar"></i> 2 weeks ago
                            </span>
                        </div>
                       
                    </div>
                </div>
            </div>


        </div>



        <!-- Video Modal -->
        <div class="modal fade" id="videoModal" tabindex="-1" aria-labelledby="videoModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="videoModalLabel">Our Activities</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <video id="modalVideo" controls style="width: 100%; border-radius: 10px;">
                            Your browser does not support the video tag.
                        </video>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


    <style>

/* Gallery Section */
.gallery-section {
    background: linear-gradient(135deg, #f8f9fa, #e9ecef);
}

.gallery-item {
    position: relative;
    border-radius: 15px;
    overflow: hidden;
    cursor: pointer;
    transition: all 0.3s ease;
    aspect-ratio: 1;
}

.gallery-item img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: all 0.3s ease;
}

.gallery-item:hover {
    transform: translateY(-10px);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
}

.gallery-item:hover img {
    transform: scale(1.1);
}

.gallery-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, rgba(44, 62, 80, 0.8), rgba(255, 107, 53, 0.6));
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: all 0.3s ease;
}

.gallery-item:hover .gallery-overlay {
    opacity: 1;
}

.gallery-overlay i {
    color: white;
    font-size: 2rem;
}

/* Gallery Modal */
#galleryModal .modal-content {
    border: none;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 25px 50px rgba(0, 0, 0, 0.3);
}

#galleryModal .modal-header {
    background: linear-gradient(135deg, var(--dark-color), #1a2530);
    color: white;
    border-bottom: 2px solid var(--primary-color);
}

#galleryModal .carousel-item img {
    height: 600px;
    object-fit: cover;
}

#galleryModal .carousel-caption {
    background: linear-gradient(transparent, rgba(0, 0, 0, 0.8));
    padding: 2rem;
    border-radius: 0 0 20px 20px;
}

#galleryModal .carousel-control-prev,
#galleryModal .carousel-control-next {
    width: 60px;
    height: 60px;
    background: rgba(255, 215, 0, 0.9);
    border-radius: 50%;
    top: 50%;
    transform: translateY(-50%);
    margin: 0 20px;
}

#galleryModal .carousel-control-prev-icon,
#galleryModal .carousel-control-next-icon {
    filter: invert(1);
}


/* Responsive Design */
@media (max-width: 991.98px) {
    .hero-title {
        font-size: 2.5rem;
    }
    
    .achievements-grid {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .content-card {
        padding: 2rem;
    }
    
    .detail-main-video {
        height: 400px;
    }
}

@media (max-width: 768px) {
    .hero-title {
        font-size: 2rem;
    }
    
    .hero-subtitle {
        font-size: 1.1rem;
    }
    
    .hero-stats {
        gap: 1rem;
    }
    
    .stat-badge {
        padding: 0.5rem 1rem;
        font-size: 0.9rem;
    }
    
    .content-item {
        flex-direction: column;
        text-align: center;
        gap: 1rem;
    }
    
    .content-icon {
        width: 60px;
        height: 60px;
        font-size: 1.3rem;
    }
    
    .cta-buttons {
        flex-direction: column;
        align-items: center;
    }
    
    .cta-buttons .btn {
        width: 100%;
        max-width: 300px;
    }
}

@media (max-width: 576px) {
    .hero-title {
        font-size: 1.8rem;
    }
    
    .content-card {
        padding: 1.5rem;
    }
    
    .detail-main-video {
        height: 300px;
    }
    
    .achievements-grid {
        grid-template-columns: 1fr;
    }
    
    .gallery-item {
        aspect-ratio: 4/3;
    }
    
    #galleryModal .carousel-item img {
        height: 400px;
    }
}



    </style>


    <!-- Gallery Section -->
    <section class="gallery-section py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h3 class="section-title text-center mb-5">Our Mining Operations</h3>
                    <p class="section-subtitle text-center mb-5">Explore our responsible mining practices through these images</p>
                </div>
            </div>
            
            <div class="row">
                <!-- Gallery Items -->
                <div class="col-lg-3 col-md-4 col-6 mb-4">
                    <div class="gallery-item" data-bs-toggle="modal" data-bs-target="#galleryModal" data-index="0">
                        <img src="assets/images/slide1.jpg" alt="Mining Operation 1" class="img-fluid">
                        <div class="gallery-overlay">
                            <i class="fas fa-search-plus"></i>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-4 col-6 mb-4">
                    <div class="gallery-item" data-bs-toggle="modal" data-bs-target="#galleryModal" data-index="1">
                        <img src="assets/images/slide2.jpg" alt="Mining Operation 2" class="img-fluid">
                        <div class="gallery-overlay">
                            <i class="fas fa-search-plus"></i>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-4 col-6 mb-4">
                    <div class="gallery-item" data-bs-toggle="modal" data-bs-target="#galleryModal" data-index="2">
                        <img src="assets/images/slide3.jpg" alt="Worker Safety" class="img-fluid">
                        <div class="gallery-overlay">
                            <i class="fas fa-search-plus"></i>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-4 col-6 mb-4">
                    <div class="gallery-item" data-bs-toggle="modal" data-bs-target="#galleryModal" data-index="3">
                        <img src="assets/images/slide4.jpg" alt="Environmental Protection" class="img-fluid">
                        <div class="gallery-overlay">
                            <i class="fas fa-search-plus"></i>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-4 col-6 mb-4">
                    <div class="gallery-item" data-bs-toggle="modal" data-bs-target="#galleryModal" data-index="4">
                        <img src="assets/images/slide5.jpg" alt="Equipment" class="img-fluid">
                        <div class="gallery-overlay">
                            <i class="fas fa-search-plus"></i>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-4 col-6 mb-4">
                    <div class="gallery-item" data-bs-toggle="modal" data-bs-target="#galleryModal" data-index="5">
                        <img src="assets/images/slide11.jpg" alt="Community Engagement" class="img-fluid">
                        <div class="gallery-overlay">
                            <i class="fas fa-search-plus"></i>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-4 col-6 mb-4">
                    <div class="gallery-item" data-bs-toggle="modal" data-bs-target="#galleryModal" data-index="6">
                        <img src="assets/images/slide7.jpg" alt="Site Management" class="img-fluid">
                        <div class="gallery-overlay">
                            <i class="fas fa-search-plus"></i>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-4 col-6 mb-4">
                    <div class="gallery-item" data-bs-toggle="modal" data-bs-target="#galleryModal" data-index="7">
                        <img src="assets/images/slide8.jpg" alt="Quality Control" class="img-fluid">
                        <div class="gallery-overlay">
                            <i class="fas fa-search-plus"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Gallery Modal -->
    <div class="modal fade" id="galleryModal" tabindex="-1" aria-labelledby="galleryModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="galleryModalLabel">Mining Operations</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="galleryCarousel" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="assets/images/slide1.jpg" class="d-block w-100" alt="Mining Operation 1">
                                <div class="carousel-caption">
                                    <h5>Modern Mining Equipment</h5>
                                    <p>State-of-the-art machinery for efficient and safe extraction</p>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <img src="assets/images/slide2.jpg" class="d-block w-100" alt="Mining Operation 2">
                                <div class="carousel-caption">
                                    <h5>Worker Safety Training</h5>
                                    <p>Regular training sessions to ensure workplace safety</p>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <img src="assets/images/slide3.jpg" class="d-block w-100" alt="Worker Safety">
                                <div class="carousel-caption">
                                    <h5>Protective Equipment</h5>
                                    <p>All workers equipped with proper safety gear</p>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <img src="assets/images/slide4.jpg" class="d-block w-100" alt="Environmental Protection">
                                <div class="carousel-caption">
                                    <h5>Environmental Monitoring</h5>
                                    <p>Continuous assessment of our ecological impact</p>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <img src="assets/images/slide5.jpg" class="d-block w-100" alt="Equipment">
                                <div class="carousel-caption">
                                    <h5>Advanced Technology</h5>
                                    <p>Using modern equipment for precise extraction</p>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <img src="assets/images/slide11.jpg" class="d-block w-100" alt="Community Engagement">
                                <div class="carousel-caption">
                                    <h5>Community Meetings</h5>
                                    <p>Regular engagement with local communities</p>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <img src="assets/images/slide7.jpg" class="d-block w-100" alt="Site Management">
                                <div class="carousel-caption">
                                    <h5>Site Organization</h5>
                                    <p>Well-maintained and organized mining sites</p>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <img src="assets/images/slide8.jpg" class="d-block w-100" alt="Quality Control">
                                <div class="carousel-caption">
                                    <h5>Quality Assessment</h5>
                                    <p>Rigorous quality control processes</p>
                                </div>
                            </div>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#galleryCarousel" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#galleryCarousel" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

   

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.js"></script>
    
    <script>
    // Gallery functionality
    document.addEventListener('DOMContentLoaded', function() {
        // Gallery item click handling
        const galleryItems = document.querySelectorAll('.gallery-item');
        const galleryCarousel = document.getElementById('galleryCarousel');
        
        galleryItems.forEach(item => {
            item.addEventListener('click', function() {
                const index = parseInt(this.getAttribute('data-index'));
                const carouselItems = galleryCarousel.querySelectorAll('.carousel-item');
                
                // Remove active class from all items
                carouselItems.forEach(cItem => cItem.classList.remove('active'));
                
                // Add active class to clicked item
                if (carouselItems[index]) {
                    carouselItems[index].classList.add('active');
                }
            });
        });
        
        // Enhanced carousel for gallery
        if (galleryCarousel) {
            galleryCarousel.addEventListener('slide.bs.carousel', function(e) {
                // Add smooth transitions
                const activeItem = e.relatedTarget;
                activeItem.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    activeItem.style.transform = 'scale(1)';
                }, 50);
            });
        }
    });
    </script>

<!-- Leadership Section -->
<section id="leadership" class="leadership-section py-5">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h2 class="section-title">Our Leadership Team</h2>
                <p class="section-subtitle">Meet the dedicated individuals guiding our community mining operations toward sustainability and shared prosperity.</p>
            </div>
        </div>

        <div class="leadership-grid">
            <!-- Chairman -->
            <div class="leader-card">
                <div class="leader-image" style="background: url('assets/images/chair.jpg') center/cover;">
                </div>
                <div class="leader-content">
                    <h3 class="leader-name">Chief John Malanda</h3>
                    <div class="leader-position">Community Chief</div>
                    <p class="leader-description">
                        John brings over 20 years of experience in community leadership and cooperative mining. As Chairman, he provides overall strategic direction, promotes transparency, and ensures equitable benefit for all members.
                    </p>
                    <div class="leader-contact">
                        <span class="contact-badge">
                            <span>cman@lubumbashigoldminers.com</span>
                        </span>
                    </div>
                </div>
            </div>

            <!-- Legal Advisor -->
            <div class="leader-card">
                <div class="leader-image" style="background: url('assets/images/legalad.jpg') center/cover;">
                </div>
                <div class="leader-content">
                    <h3 class="leader-name">Kabongo Andrew</h3>
                    <div class="leader-position">Legal Advisor</div>
                    <p class="leader-description">
                        Kabongo oversees legal compliance, ensuring all mining operations adhere to both local and international laws. He drafts agreements, manages contracts, and safeguards miners' rights through ethical governance.
                    </p>
                    <div class="leader-contact">
                        <span class="contact-badge">
                            <span>legal@lubumbashigoldminers.com</span>
                        </span>
                    </div>
                </div>
            </div>

            <!-- Underground Operations Manager -->
            <div class="leader-card">
                <div class="leader-image" style="background: url('assets/images/patrick.jpg') center/cover;">
                </div>
                <div class="leader-content">
                    <h3 class="leader-name">Patrick Kimbangu</h3>
                    <div class="leader-position">Underground Operations Manager</div>
                    <p class="leader-description">
                        A skilled mining engineer, Patrick oversees underground operations with a focus on safety, technical precision, and sustainability. 
                        His expertise drives efficiency and environmental responsibility.
                    </p>
                    <div class="leader-contact">
                        <span class="contact-badge">
                            <span>mngr@lubumbashigoldminers.com</span>
                        </span>
                    </div>
                </div>
            </div>

            <!-- Head of Security -->
            <div class="leader-card">
                <div class="leader-image" style="background: url('assets/images/mwamba.jpg') center/cover;">
                </div>
                <div class="leader-content">
                    <h3 class="leader-name">Jacques Mwamba</h3>
                    <div class="leader-position">Head of Security</div>
                    <p class="leader-description">
                        Jacques, a retired security officer, manages all safety operations at mining sites. He ensures secure gold transport, protects miners, and coordinates with authorities for site security.
                    </p>
                    <div class="leader-contact">
                        <span class="contact-badge">
                            <span>hosec@lubumbashigoldminers.com</span>
                        </span>
                    </div>
                </div>
            </div>

            <!-- Welfare Officer -->
            <div class="leader-card">
                 <div class="leader-image" style="background: url('assets/images/chantal.png') center/cover;">
                </div>
                <div class="leader-content">
                    <h3 class="leader-name">Chantal Kalonji</h3>
                    <div class="leader-position">Welfare Officer</div>
                    <p class="leader-description">
                        Chantal focuses on improving the wellbeing of miners and their families by coordinating access to food, medical care, and housing. She advocates for better working and living conditions.
                    </p>
                    <div class="leader-contact">
                        <span class="contact-badge">
                            <span>welf@lubumbashigoldminers.com</span>
                        </span>
                    </div>
                </div>
            </div>

            <!-- Education Officer -->
            <div class="leader-card">
                 <div class="leader-image" style="background: url('assets/images/juliene.jfif') center/cover;">
                </div>
                <div class="leader-content">
                    <h3 class="leader-name">Julienne Tshimanga</h3>
                    <div class="leader-position">Education and Training Officer</div>
                    <p class="leader-description">
                        Julienne leads training initiatives on sustainable mining, health, and financial literacy. Her programs empower miners with knowledge and skills for long-term growth and community development.
                    </p>
                    <div class="leader-contact">
                        <span class="contact-badge">
                            <span>edu@lubumbashigoldminers.com</span>
                        </span>
                    </div>
                </div>
            </div>

            <!-- Artisanal Miners Representative -->
            <div class="leader-card">
                 <div class="leader-image" style="background: url('assets/images/andre.jpg') center/cover;">
                </div>
                <div class="leader-content">
                    <h3 class="leader-name">André Kasongo</h3>
                    <div class="leader-position">Head of Artisanal Miners</div>
                    <p class="leader-description">
                        André represents small-scale miners, coordinating their activities and ensuring fair access to tools and resources. He also promotes safe and responsible artisanal mining practices.
                    </p>
                    <div class="leader-contact">
                        <span class="contact-badge">
                            <span>art@lubumbashigoldminers.com</span>
                        </span>
                    </div>
                </div>
            </div>

            <!-- Community Health Officer -->
            <div class="leader-card">
                 <div class="leader-image" style="background: url('assets/images/david.jfif') center/cover;">
                </div>
                <div class="leader-content">
                    <h3 class="leader-name">David Sango</h3>
                    <div class="leader-position">Community Health Officer</div>
                    <p class="leader-description">
                        David oversees the health and safety of all workers. He partners with local clinics to provide medical support, prevent disease outbreaks, and ensure miners' wellbeing across all sites.
                    </p>
                    <div class="leader-contact">
                        <span class="contact-badge">
                            <span>david@lubumbashigoldminers.com</span>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



















<style>

/* Leadership Section Styles */
.leadership-section {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
}

.leadership-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
    margin-top: 3rem;
}

.leader-card {
    background: white;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.leader-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
}

.leader-image {
    height: 250px;
    position: relative;
}

.leader-content {
    padding: 2rem;
}

.leader-name {
    font-size: 1.25rem;
    font-weight: 700;
    color: var(--dark-color);
    margin-bottom: 0.5rem;
}

.leader-position {
    color: var(--primary-color);
    font-weight: 600;
    font-size: 0.9rem;
    margin-bottom: 1rem;
}

.leader-description {
    color: #666;
    line-height: 1.6;
    margin-bottom: 1.5rem;
}

.leader-contact {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
}

.contact-badge {
    background: var(--primary-color);
    color: var(--dark-color);
    padding: 0.5rem 1rem;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 500;
}

/* Responsive Design */
@media (max-width: 768px) {
    .leadership-grid {
        grid-template-columns: 1fr;
        gap: 1.5rem;
    }
    
    .leader-content {
        padding: 1.5rem;
    }
}

/* Read More Buttons */
.read-more-btn {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    background: linear-gradient(135deg, var(--primary-color), #ffed4e);
    color: var(--dark-color);
    border: none;
    padding: 0.75rem 1.5rem;
    border-radius: 25px;
    font-weight: 600;
    font-size: 0.9rem;
    cursor: pointer;
    transition: all 0.3s ease;
    margin-top: 1rem;
    text-decoration: none;
    box-shadow: 0 4px 15px rgba(255, 215, 0, 0.3);
}

.read-more-btn:hover {
    background: linear-gradient(135deg, var(--secondary-color), #ff8c5a);
    color: white;
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(255, 107, 53, 0.4);
    text-decoration: none;
}

.read-more-btn i {
    font-size: 0.8rem;
    transition: transform 0.3s ease;
}

.read-more-btn:hover i {
    transform: translateX(3px);
}

/* Video Content Adjustments for Read More Button */
.video-content {
    padding: 2rem;
    position: relative;
    display: flex;
    flex-direction: column;
    height: 100%;
}

.video-content p {
    flex-grow: 1;
    margin-bottom: 1rem;
}

.video-stats {
    margin-top: auto;
}

/* Enhanced Video Card with Read More */
.video-card {
    background: white;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    border: 1px solid rgba(255, 215, 0, 0.1);
    height: 100%;
    display: flex;
    flex-direction: column;
}

.video-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 20px 50px rgba(0, 0, 0, 0.15);
    border-color: var(--primary-color);
}

.video-container {
    position: relative;
    width: 100%;
    height: 220px;
    overflow: hidden;
    background: var(--dark-color);
    flex-shrink: 0;
}

/* Responsive Adjustments for Read More Buttons */
@media (max-width: 768px) {
    .read-more-btn {
        padding: 0.6rem 1.25rem;
        font-size: 0.85rem;
    }
    
    .video-content {
        padding: 1.5rem;
    }
}

@media (max-width: 576px) {
    .read-more-btn {
        padding: 0.5rem 1rem;
        font-size: 0.8rem;
        width: 100%;
        justify-content: center;
    }
    
    .video-content {
        padding: 1.25rem;
    }
}

/* Animation for Read More Buttons */
.read-more-btn {
    animation: fadeInUp 0.6s ease forwards;
    opacity: 0;
    transform: translateY(10px);
}

.video-card:nth-child(1) .read-more-btn { animation-delay: 0.3s; }
.video-card:nth-child(2) .read-more-btn { animation-delay: 0.4s; }
.video-card:nth-child(3) .read-more-btn { animation-delay: 0.5s; }
.video-card:nth-child(4) .read-more-btn { animation-delay: 0.6s; }
.video-card:nth-child(5) .read-more-btn { animation-delay: 0.7s; }
.video-card:nth-child(6) .read-more-btn { animation-delay: 0.8s; }

@keyframes fadeInUp {
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
</style>
<script>
// Read More Button Functionality
document.addEventListener('DOMContentLoaded', function() {
    const readMoreButtons = document.querySelectorAll('.read-more-btn');
    
    readMoreButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const pageName = this.getAttribute('data-page');
            const pageTitle = this.closest('.video-card').querySelector('h4').textContent;
            
            // Show loading state
            const originalText = this.innerHTML;
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
            this.disabled = true;
            
            // Simulate page load (replace with actual page navigation)
            setTimeout(() => {
                // Reset button state
                this.innerHTML = originalText;
                this.disabled = false;
                
                // Navigate to detailed page (you can replace this with actual page routing)
                navigateToDetailPage(pageName, pageTitle);
            }, 1000);
        });
    });
    
    function navigateToDetailPage(pageName, pageTitle) {
        // For demonstration, we'll show an alert
        // In a real implementation, you would redirect to the actual page
        //alert(`Navigating to: ${pageTitle}\nPage: ${pageName}.html`);
        
        // Example of actual navigation (uncomment when you have the pages):
        window.location.href = `${pageName}.php`;
        
        // Alternatively, you can use:
        // window.open(`activities/${pageName}.html`, '_blank');
    }
    
    // Enhanced video card interactions with read more
    const videoCards = document.querySelectorAll('.video-card');
    
    videoCards.forEach(card => {
        const readMoreBtn = card.querySelector('.read-more-btn');
        
        card.addEventListener('mouseenter', function() {
            if (readMoreBtn) {
                readMoreBtn.style.transform = 'translateY(-2px)';
            }
        });
        
        card.addEventListener('mouseleave', function() {
            if (readMoreBtn) {
                readMoreBtn.style.transform = 'translateY(0)';
            }
        });
    });
});
</script>

   


<!-- FAQs in Collapsible -->
    <!-- FAQs in Collapsible -->
    <section id="faqs" class="faq-section py-5">
        <div class="container">
            <h2 class="section-title text-center mb-5">Frequently Asked Questions</h2>
            <div class="row justify-content-center">
                <div class="col-xxl-10">
                    <div class="row">
                        <!-- First Column -->
                        <div class="col-lg-6">
                            <div class="accordion" id="faqAccordionLeft">
                                <!-- Question 1 -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingOne">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                            <span class="question-number">01</span>
                                            Why do people think gold from Congo is a scam?
                                        </button>
                                    </h2>
                                    <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#faqAccordionLeft">
                                        <div class="accordion-body">
                                            This misconception exists because many scammers falsely use Congolese identities and forged certificates of origin to sell fake gold. They often claim to represent Congolese miners, using counterfeit documents and passports to appear legitimate. The Lubumbashi Community Gold Miners Association works hard to protect genuine dealers and buyers by promoting verified, transparent, and ethical gold trade.
                                        </div>
                                    </div>
                                </div>

                                <!-- Question 2 -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingTwo">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                            <span class="question-number">02</span>
                                            How can I join Lubumbashi Community Gold Miners?
                                        </button>
                                    </h2>
                                    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#faqAccordionLeft">
                                        <div class="accordion-body">
                                            You can support our community by donating to our humanitarian initiatives, which include providing food, medicine, shelter, and clothing to local miners and their families. Every contribution helps improve the welfare and working conditions of our members.
                                        </div>
                                    </div>
                                </div>

                                <!-- Question 3 -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingThree">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                            <span class="question-number">03</span>
                                            What community projects do you support?
                                        </button>
                                    </h2>
                                    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#faqAccordionLeft">
                                        <div class="accordion-body">
                                            We support education through school construction and scholarships, healthcare via medical facilities and mobile clinics, infrastructure development including clean water systems, and skills training programs that benefit over 10,000 community members annually.
                                        </div>
                                    </div>
                                </div>

                                <!-- Question 4 -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingFour">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                            <span class="question-number">04</span>
                                            How can I contact Lubumbashi Community Gold Miners?
                                        </button>
                                    </h2>
                                    <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#faqAccordionLeft">
                                        <div class="accordion-body">
                                            Due to limited network infrastructure in our region, we primarily communicate through WhatsApp messages and email. You can find our contact details on the Contact Us page of our website.
                                        </div>
                                    </div>
                                </div>

                                <!-- Question 5 -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingFive">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                            <span class="question-number">05</span>
                                            How do I transport my gold safely?
                                        </button>
                                    </h2>
                                    <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#faqAccordionLeft">
                                        <div class="accordion-body">
                                            Because of ongoing regional conflicts, we do not handle direct gold transportation. Instead, we partner with licensed and trusted transport agents who ship gold securely through neighboring safe countries such as Uganda, Kenya, and Tanzania. This ensures full traceability and the safety of your consignment.
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br/>
                        </div>

                        <!-- Second Column -->
                        <div class="col-lg-6">
                            <div class="accordion" id="faqAccordionRight">
                                <!-- Question 6 -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingSix">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                            <span class="question-number">06</span>
                                            What type of gold is found in Lubumbashi?
                                        </button>
                                    </h2>
                                    <div id="collapseSix" class="accordion-collapse collapse" aria-labelledby="headingSix" data-bs-parent="#faqAccordionRight">
                                        <div class="accordion-body">
                                            Lubumbashi is rich in natural gold nuggets of exceptional purity, mined through both artisanal and community-based methods under strict ethical standards.
                                        </div>
                                    </div>
                                </div>

                                <!-- Question 7 -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingSeven">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                                            <span class="question-number">07</span>
                                            What is the minimum and maximum amount of gold I can buy?
                                        </button>
                                    </h2>
                                    <div id="collapseSeven" class="accordion-collapse collapse" aria-labelledby="headingSeven" data-bs-parent="#faqAccordionRight">
                                        <div class="accordion-body">
                                            Buyers can purchase a minimum of 1 kilogram (1 kg) and up to a maximum of 500 kilograms (500 kg) per transaction, depending on availability and agreement terms.
                                        </div>
                                    </div>
                                </div>

                                <!-- Question 8 -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingEight">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
                                            <span class="question-number">08</span>
                                            Is it true that cheap gold from Congo is a scam?
                                        </button>
                                    </h2>
                                    <div id="collapseEight" class="accordion-collapse collapse" aria-labelledby="headingEight" data-bs-parent="#faqAccordionRight">
                                        <div class="accordion-body">
                                            Not necessarily. The gold is genuine, but some miners sell at lower prices to meet urgent personal and family needs. However, scammers exploit this situation by offering fake deals. To protect yourself, always verify the source and consult directly with Lubumbashi Community Gold Miners before any transaction.
                                        </div>
                                    </div>
                                </div>

                                <!-- Question 9 -->

                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingTen">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
                                            <span class="question-number">09</span>
                                            What are the benefits of buying gold from Lubumbashi Community Gold Miners?
                                        </button>
                                    </h2>
                                    <div id="collapseTen" class="accordion-collapse collapse" aria-labelledby="headingTen" data-bs-parent="#faqAccordionRight">
                                        <div class="accordion-body">
                                            <ul>
                                                <li>Our gold is authentic and competitively priced.</li>
                                                <li>We guarantee purity and transparency in every transaction.</li>
                                                <li>We have the capacity to supply any volume, ensuring reliability for both small and large-scale buyers.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<!-- Trust Indicators -->
    <section class="trust-section py-5">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-3 col-6 mb-4">
                    <div class="trust-item">
                        <i class="fas fa-certificate"></i>
                        <h4>Global Trader</h4>
                        <p>International Gold Trader</p>
                    </div>
                </div>
                <div class="col-md-3 col-6 mb-4">
                    <div class="trust-item">
                        <i class="fas fa-shield-alt"></i>
                        <h4>Secure</h4>
                        <p>Safe and transparent transactions</p>
                    </div>
                </div>
                <div class="col-md-3 col-6 mb-4">
                    <div class="trust-item">
                        <i class="fas fa-users"></i>
                        <h4>Community</h4>
                        <p>Supporting local development</p>
                    </div>
                </div>
                <div class="col-md-3 col-6 mb-4">
                    <div class="trust-item">
                        <i class="fas fa-leaf"></i>
                        <h4>Sustainable</h4>
                        <p>Environmentally responsible practices</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Process Section -->
    <section id="process" class="process-section py-5">
        <div class="container">
            <h2 class="section-title text-center mb-5">Our Mining Process</h2>
            <div class="row">
                <div class="col-md-4 process-step">
                    <div class="step-number">1</div>
                    <h4>Exploration</h4>
                    <p>Scientific assessment and community-approved site selection</p>
                </div>
                <div class="col-md-4 process-step">
                    <div class="step-number">2</div>
                    <h4>Extraction</h4>
                    <p>Manual and semi-mechanized extraction with minimal environmental impact</p>
                </div>
                <div class="col-md-4 process-step">
                    <div class="step-number">3</div>
                    <h4>Processing</h4>
                    <p>Modern facilities ensuring purity and quality standards</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Our Impact Section -->
<section id="impact" class="impact-section py-5">
    <div class="container">
        <h2 class="section-title text-center mb-5">Our Impact</h2>
        
        

        <!-- Impact Description Cards -->
        <div class="row mt-5">
            <div class="col-md-4 mb-4">
                <div class="impact-feature-card">
                    <div class="card-floating-icon">
                        <i class="fas fa-home"></i>
                    </div>
                    <div class="card-content">
                        <div class="card-icon">
                            <i class="fas fa-home"></i>
                        </div>
                        <h4>Community Development</h4>
                        <p>Built schools, healthcare centers, and infrastructure projects benefiting over 10,000 people in local communities.</p>
                        <div class="card-stats">
                            <div class="mini-stat">
                                <span class="mini-number">15</span>
                                <span class="mini-label">Schools Built</span>
                            </div>
                            <div class="mini-stat">
                                <span class="mini-number">5</span>
                                <span class="mini-label">Health Centers</span>
                            </div>
                        </div>
                    </div>
                    <div class="card-glow"></div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="impact-feature-card">
                    <div class="card-floating-icon">
                        <i class="fas fa-tree"></i>
                    </div>
                    <div class="card-content">
                        <div class="card-icon">
                            <i class="fas fa-tree"></i>
                        </div>
                        <h4>Environmental Care</h4>
                        <p>Replanted 5,000+ trees and implemented advanced water conservation systems across our mining sites.</p>
                        <div class="card-stats">
                            <div class="mini-stat">
                                <span class="mini-number">5K+</span>
                                <span class="mini-label">Trees Planted</span>
                            </div>
                            <div class="mini-stat">
                                <span class="mini-number">12</span>
                                <span class="mini-label">Water Systems</span>
                            </div>
                        </div>
                    </div>
                    <div class="card-glow"></div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="impact-feature-card">
                    <div class="card-floating-icon">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <div class="card-content">
                        <div class="card-icon">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <h4>Education Support</h4>
                        <p>Provided scholarships, educational resources, and training programs for 200+ children and young adults.</p>
                        <div class="card-stats">
                            <div class="mini-stat">
                                <span class="mini-number">200+</span>
                                <span class="mini-label">Students</span>
                            </div>
                            <div class="mini-stat">
                                <span class="mini-number">50</span>
                                <span class="mini-label">Scholarships</span>
                            </div>
                        </div>
                    </div>
                    <div class="card-glow"></div>
                </div>
            </div>
        </div>

        <!-- Additional Impact Cards -->
        <div class="row mt-4">
            <div class="col-md-4 mb-4">
                <div class="impact-feature-card">
                    <div class="card-floating-icon">
                        <i class="fas fa-hand-holding-medical"></i>
                    </div>
                    <div class="card-content">
                        <div class="card-icon">
                            <i class="fas fa-hand-holding-medical"></i>
                        </div>
                        <h4>Healthcare Access</h4>
                        <p>Established medical facilities providing free healthcare services to over 2,500 community members annually.</p>
                        <div class="card-stats">
                            <div class="mini-stat">
                                <span class="mini-number">2.5K</span>
                                <span class="mini-label">Patients/Yr</span>
                            </div>
                            <div class="mini-stat">
                                <span class="mini-number">3</span>
                                <span class="mini-label">Clinics</span>
                            </div>
                        </div>
                    </div>
                    <div class="card-glow"></div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="impact-feature-card">
                    <div class="card-floating-icon">
                        <i class="fas fa-solar-panel"></i>
                    </div>
                    <div class="card-content">
                        <div class="card-icon">
                            <i class="fas fa-solar-panel"></i>
                        </div>
                        <h4>Sustainable Energy</h4>
                        <p>Implemented solar power systems reducing carbon emissions by 40% across our mining operations.</p>
                        <div class="card-stats">
                            <div class="mini-stat">
                                <span class="mini-number">40%</span>
                                <span class="mini-label">Less Emissions</span>
                            </div>
                            <div class="mini-stat">
                                <span class="mini-number">8</span>
                                <span class="mini-label">Solar Farms</span>
                            </div>
                        </div>
                    </div>
                    <div class="card-glow"></div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="impact-feature-card">
                    <div class="card-floating-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="card-content">
                        <div class="card-icon">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <h4>Economic Growth</h4>
                        <p>Generated $5M+ in local economic development through fair wages and community investment programs.</p>
                        <div class="card-stats">
                            <div class="mini-stat">
                                <span class="mini-number">$5M+</span>
                                <span class="mini-label">Invested</span>
                            </div>
                            <div class="mini-stat">
                                <span class="mini-number">25%</span>
                                <span class="mini-label">Growth</span>
                            </div>
                        </div>
                    </div>
                    <div class="card-glow"></div>
                </div>
            </div>
        </div>
    </div>
</section>

 
    <style>
        :root {
            --primary-color: #FFD700;
            --secondary-color: #FF8C00;
            --dark-color: #1a2530;
            --light-bg: #f8f9fa;
        }
        
        /* Modern Reviews Section */
        .reviews-section {
            padding: 100px 0;
            background: linear-gradient(135deg, #ffffff 0%, var(--light-bg) 100%);
            position: relative;
            overflow: hidden;
        }

        .reviews-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--primary-color), transparent);
        }

        .section-header {
            text-align: center;
            margin-bottom: 4rem;
        }

        .section-title {
            font-size: 3rem;
            font-weight: 800;
            color: var(--dark-color);
            margin-bottom: 1rem;
            position: relative;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
            border-radius: 2px;
        }

        .section-subtitle {
            font-size: 1.2rem;
            color: #666;
            max-width: 600px;
            margin: 0 auto;
            line-height: 1.6;
        }

        /* Modern Layout */
        .reviews-layout {
            display: grid;
            grid-template-columns: 1fr;
            gap: 3rem;
        }

        @media (min-width: 1200px) {
            .reviews-layout {
                grid-template-columns: 1fr 1fr;
                gap: 4rem;
            }
        }

        /* Modern Form Card */
        .review-form-card {
            background: white;
            border-radius: 24px;
            padding: 3rem;
            box-shadow: 
                0 20px 60px rgba(0, 0, 0, 0.08),
                0 0 0 1px rgba(255, 215, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(10px);
            position: relative;
            overflow: hidden;
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        .review-form-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
        }

        .review-form-card:hover {
            transform: translateY(-5px);
            box-shadow: 
                0 30px 80px rgba(0, 0, 0, 0.12),
                0 0 0 1px rgba(255, 215, 0, 0.2);
        }

        .form-header {
            text-align: center;
            margin-bottom: 2.5rem;
        }

        .form-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
            color: white;
            font-size: 2rem;
            box-shadow: 0 10px 30px rgba(255, 215, 0, 0.3);
        }

        .form-title {
            font-size: 2rem;
            font-weight: 700;
            color: var(--dark-color);
            margin-bottom: 0.5rem;
        }

        .form-subtitle {
            color: #666;
            font-size: 1rem;
        }

        /* Modern Form Elements */
        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-label {
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 0.75rem;
            font-size: 0.95rem;
        }

        .form-control {
            border-radius: 12px;
            padding: 1rem 1.25rem;
            border: 2px solid #e8e8e8;
            background: #fafafa;
            transition: all 0.3s ease;
            font-size: 1rem;
        }

        .form-control:focus {
            border-color: var(--primary-color);
            background: white;
            box-shadow: 0 0 0 4px rgba(255, 215, 0, 0.15);
            transform: translateY(-2px);
        }

        /* Modern Rating System */
        .rating-container {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 1.5rem;
            border: 2px dashed rgba(255, 215, 0, 0.3);
        }

        .rating-input {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 0;
            flex-direction: row-reverse;
            justify-content: center;
        }

        .rating-input input {
            display: none;
        }

        .rating-input label {
            font-size: 2.5rem;
            color: #e0e0e0;
            cursor: pointer;
            transition: all 0.3s ease;
            filter: drop-shadow(0 2px 4px rgba(0,0,0,0.1));
        }

        .rating-input input:checked ~ label,
        .rating-input label:hover,
        .rating-input label:hover ~ label {
            color: var(--primary-color);
            transform: scale(1.1);
            filter: drop-shadow(0 4px 8px rgba(255, 215, 0, 0.3));
        }

        /* Modern Button */
        .submit-review-btn {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: var(--dark-color);
            border: none;
            padding: 1rem 2.5rem;
            border-radius: 50px;
            font-weight: 700;
            font-size: 1.1rem;
            transition: all 0.4s ease;
            width: 100%;
            margin-top: 1rem;
            position: relative;
            overflow: hidden;
        }

        .submit-review-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            transition: left 0.5s;
        }

        .submit-review-btn:hover {
            transform: translateY(-3px);
            box-shadow: 
                0 15px 30px rgba(255, 215, 0, 0.4),
                0 0 0 1px rgba(255, 215, 0, 0.2);
        }

        .submit-review-btn:hover::before {
            left: 100%;
        }

        /* Modern Reviews Side */
        .reviews-side {
            display: flex;
            flex-direction: column;
        }

        .reviews-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding: 0 1rem;
        }

        .reviews-title {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--dark-color);
            margin: 0;
        }

        .reviews-stats {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .average-rating {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            background: rgba(255, 215, 0, 0.1);
            padding: 0.5rem 1rem;
            border-radius: 20px;
            border: 1px solid rgba(255, 215, 0, 0.3);
        }

        .rating-number {
            font-weight: 700;
            color: var(--dark-color);
            font-size: 1.2rem;
        }

        .reviews-count {
            color: #666;
            font-size: 0.9rem;
        }

        /* Modern Reviews Container */
        .reviews-container {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
            max-height: 930px;
            overflow-y: auto;
            padding: 1rem;
            scrollbar-width: thin;
            scrollbar-color: var(--primary-color) transparent;
        }

        .reviews-container::-webkit-scrollbar {
            width: 6px;
        }

        .reviews-container::-webkit-scrollbar-track {
            background: transparent;
        }

        .reviews-container::-webkit-scrollbar-thumb {
            background: var(--primary-color);
            border-radius: 10px;
        }

        /* Modern Review Card - Updated for 2-line preview */
          /* UPDATED: Modern Review Card - Fixed width for horizontal scrolling */
    .review-card {
        background: white;
        border-radius: 20px;
        padding: 2rem;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.06);
        border: 1px solid rgba(255, 215, 0, 0.1);
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
        cursor: pointer;
        min-width: 350px;
        max-width: 550px;
        flex-shrink: 0;
        height: fit-content;
    }

        .review-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .review-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
        }

        .review-card:hover::before {
            opacity: 1;
        }

        .review-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1.25rem;
        }

        .reviewer-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .reviewer-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.3rem;
            box-shadow: 0 5px 15px rgba(255, 215, 0, 0.3);
            flex-shrink: 0;
        }

        .reviewer-details {
            flex: 1;
        }

        .reviewer-name {
            font-weight: 700;
            color: var(--dark-color);
            margin-bottom: 0.25rem;
            font-size: 1.1rem;
        }

        .review-date {
            color: #888;
            font-size: 0.85rem;
        }

        .review-rating {
            display: flex;
            gap: 0.25rem;
            flex-shrink: 0;
        }

        .star {
            color: #e0e0e0;
            font-size: 1.2rem;
        }

        .star.filled {
            color: var(--primary-color);
            filter: drop-shadow(0 2px 4px rgba(255, 215, 0, 0.3));
        }

        /* Updated Review Content for 2-line preview */
        .review-content {
            color: #555;
            line-height: 1.7;
            font-size: 1rem;
            position: relative;
            overflow: hidden;
        }

        .review-preview {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            margin-bottom: 0.5rem;
        }

        .read-more {
            color: var(--primary-color);
            font-weight: 600;
            font-size: 0.9rem;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
            transition: all 0.3s ease;
        }

        .read-more:hover {
            color: var(--secondary-color);
            transform: translateX(3px);
        }

        /* No Reviews State */
        .no-reviews {
            text-align: center;
            padding: 4rem 2rem;
            color: #888;
            background: rgba(255, 215, 0, 0.05);
            border-radius: 20px;
            border: 2px dashed rgba(255, 215, 0, 0.3);
        }

        .no-reviews i {
            font-size: 4rem;
            margin-bottom: 1.5rem;
            color: #e0e0e0;
        }

        .no-reviews h4 {
            color: #666;
            margin-bottom: 1rem;
            font-weight: 600;
        }

        /* Alert Styles */
        .alert {
            border-radius: 12px;
            border: none;
            padding: 1.25rem 1.5rem;
            margin-bottom: 2rem;
        }

        /* Custom Modal Styles */
        .review-modal .modal-content {
            border-radius: 24px;
            border: none;
            box-shadow: 0 30px 80px rgba(0, 0, 0, 0.15);
            overflow: hidden;
        }

        .review-modal .modal-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: var(--dark-color);
            border-bottom: none;
            padding: 2rem;
            position: relative;
        }

        .review-modal .modal-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="50" cy="50" r="1" fill="%23ffffff" opacity="0.1"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
            opacity: 0.3;
        }

        .review-modal .modal-title {
            font-weight: 800;
            font-size: 1.5rem;
            position: relative;
            z-index: 2;
        }

        .review-modal .btn-close {
            position: relative;
            z-index: 2;
            opacity: 0.8;
        }

        .review-modal .btn-close:hover {
            opacity: 1;
        }

        .review-modal .modal-body {
            padding: 2.5rem;
        }

        .modal-reviewer-info {
            display: flex;
            align-items: center;
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .modal-reviewer-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.5rem;
            box-shadow: 0 8px 25px rgba(255, 215, 0, 0.4);
            flex-shrink: 0;
        }

        .modal-reviewer-details {
            flex: 1;
        }

        .modal-reviewer-name {
            font-weight: 700;
            color: var(--dark-color);
            margin-bottom: 0.5rem;
            font-size: 1.3rem;
        }

        .modal-review-date {
            color: #888;
            font-size: 1rem;
            margin-bottom: 0.5rem;
        }

        .modal-review-rating {
            display: flex;
            gap: 0.25rem;
        }

        .modal-review-content {
            color: #555;
            line-height: 1.8;
            font-size: 1.1rem;
            background: rgba(255, 215, 0, 0.05);
            padding: 2rem;
            border-radius: 16px;
            border-left: 4px solid var(--primary-color);
        }

        /* Responsive Design */
        @media (max-width: 1199.98px) {
            .reviews-layout {
                gap: 2rem;
            }
            
            .review-form-card {
                padding: 2.5rem;
            }
        }

        @media (max-width: 768px) {
            .reviews-section {
                padding: 80px 0;
            }
            
            .section-title {
                font-size: 2.5rem;
            }
            
            .review-form-card {
                padding: 2rem;
            }
            
            .form-icon {
                width: 70px;
                height: 70px;
                font-size: 1.8rem;
            }
            
            .form-title {
                font-size: 1.8rem;
            }
            
            .reviews-header {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }
            
            .review-header {
                flex-direction: column;
                gap: 1rem;
                align-items: flex-start;
            }
            
            .reviewer-info {
                width: 100%;
            }

            .review-modal .modal-body {
                padding: 2rem 1.5rem;
            }

            .modal-reviewer-info {
                flex-direction: column;
                text-align: center;
                gap: 1rem;
            }
        }

        @media (max-width: 576px) {
            .section-title {
                font-size: 2rem;
            }
            
            .review-form-card {
                padding: 1.5rem;
            }
            
            .rating-input label {
                font-size: 2rem;
            }
            
            .reviewer-avatar {
                width: 50px;
                height: 50px;
                font-size: 1.1rem;
            }

            .modal-reviewer-avatar {
                width: 60px;
                height: 60px;
                font-size: 1.2rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation would be here -->
    
    <!-- Modern Reviews Section -->
    <section class="reviews-section" id="reviews">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">Feedback / Reviews</h2>
                <p class="section-subtitle">Share your experience with Lubumbashi Gold Miners. All reviews are moderated before publication to ensure authenticity.</p>
            </div>

            <div class="reviews-layout">
                <!-- Review Form Side -->
                <div class="review-form-side">
                    <div class="review-form-card">
                        <div class="form-header">
                            <div class="form-icon">
                                <i class="fas fa-pen-fancy"></i>
                            </div>
                            <h3 class="form-title">Share Your Experience</h3>
                            <p class="form-subtitle">Your feedback helps us improve our services</p>
                        </div>
                        
                                                
                        <form id="reviewForm" action="submit_review.php" method="POST">
                            <div class="form-group">
                                <label for="reviewerName" class="form-label">Your Name *</label>
                                <input type="text" class="form-control" id="reviewerName" name="reviewer_name" placeholder="Enter your full name" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="reviewerEmail" class="form-label">Email Address *</label>
                                <input type="email" class="form-control" id="reviewerEmail" name="reviewer_email" placeholder="your.email@example.com" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Your Rating *</label>
                                <div class="rating-container">
                                    <div class="rating-input">
                                        <input type="radio" id="star5" name="rating" value="5" required>
                                        <label for="star5" title="Excellent">★</label>
                                        <input type="radio" id="star4" name="rating" value="4">
                                        <label for="star4" title="Very Good">★</label>
                                        <input type="radio" id="star3" name="rating" value="3">
                                        <label for="star3" title="Good">★</label>
                                        <input type="radio" id="star2" name="rating" value="2">
                                        <label for="star2" title="Fair">★</label>
                                        <input type="radio" id="star1" name="rating" value="1">
                                        <label for="star1" title="Poor">★</label>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="reviewText" class="form-label">Your Review *</label>
                                <textarea class="form-control" id="reviewText" name="review_text" rows="4" placeholder="Tell us about your experience with our gold mining services..." required></textarea>
                            </div>
                            
                            <button type="submit" class="btn submit-review-btn">
                                <i class="fas fa-paper-plane me-2"></i>Submit Review
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Reviews Display Side -->
                <div class="reviews-side">
                    <div class="reviews-header">
                        <h3 class="reviews-title">Reviews / Feedback</h3>
                        <div class="reviews-stats">
                            <div class="average-rating">
                                <span class="rating-number">4.8</span>
                                <div class="stars">
                                    <span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star">★</span>                                </div>
                            </div>
                            <span class="reviews-count">Based on 47 reviews</span>
                        </div>
                    </div>

                    <div class="reviews-container">
                        
                                <div class="review-card" data-bs-toggle="modal" data-bs-target="#reviewModal3">
                                    <div class="review-header">
                                        <div class="reviewer-info">
                                            <div class="reviewer-avatar">JI</div>
                                            <div class="reviewer-details">
                                                <div class="reviewer-name">Joseph Ilunga</div>
                                                <div class="review-date">November 19, 2025</div>
                                            </div>
                                        </div>
                                        <div class="review-rating">
                                            <span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span>
                                        </div>
                                    </div>
                                   
                                </div>
                                <div class="modal fade review-modal" id="reviewModal3" tabindex="-1" aria-labelledby="reviewModalLabel3" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="reviewModalLabel3">Feedback / Review</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="modal-reviewer-info">
                                                    <div class="modal-reviewer-avatar">JI</div>
                                                    <div class="modal-reviewer-details">
                                                        <div class="modal-reviewer-name">Joseph Ilunga</div>
                                                        <div class="modal-review-date">November 19, 2025</div>
                                                        <div class="modal-review-rating">
                                                            <span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-review-content">
                                                    The leadership team truly listens to the miners. Our working conditions have improved significantly, and we feel valued as partners in this enterprise.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="review-card" data-bs-toggle="modal" data-bs-target="#reviewModal10">
                                    <div class="review-header">
                                        <div class="reviewer-info">
                                            <div class="reviewer-avatar">MR</div>
                                            <div class="reviewer-details">
                                                <div class="reviewer-name">Michael Robertson</div>
                                                <div class="review-date">November 1, 2025</div>
                                            </div>
                                        </div>
                                        <div class="review-rating">
                                            <span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span>
                                        </div>
                                    </div>
                                   
                                </div>
                                <div class="modal fade review-modal" id="reviewModal10" tabindex="-1" aria-labelledby="reviewModalLabel10" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="reviewModalLabel10">Feedback / Review</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="modal-reviewer-info">
                                                    <div class="modal-reviewer-avatar">MR</div>
                                                    <div class="modal-reviewer-details">
                                                        <div class="modal-reviewer-name">Michael Robertson</div>
                                                        <div class="modal-review-date">November 1, 2025</div>
                                                        <div class="modal-review-rating">
                                                            <span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-review-content">
                                                    As a supplier to the Royal Mint, our standards are exceptionally high. Lubumbashi Gold Miners consistently meets these standards with their professionally assayed gold. Their logistical efficiency in shipping to the UK is impressive, with minimal delays and excellent communication throughout.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="review-card" data-bs-toggle="modal" data-bs-target="#reviewModal11">
                                    <div class="review-header">
                                        <div class="reviewer-info">
                                            <div class="reviewer-avatar">DR</div>
                                            <div class="reviewer-details">
                                                <div class="reviewer-name">Dr. Rebecca Johnson</div>
                                                <div class="review-date">October 10, 2025</div>
                                            </div>
                                        </div>
                                        <div class="review-rating">
                                            <span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span>
                                        </div>
                                    </div>
                                   
                                </div>
                                <div class="modal fade review-modal" id="reviewModal11" tabindex="-1" aria-labelledby="reviewModalLabel11" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="reviewModalLabel11">Feedback / Review</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="modal-reviewer-info">
                                                    <div class="modal-reviewer-avatar">DR</div>
                                                    <div class="modal-reviewer-details">
                                                        <div class="modal-reviewer-name">Dr. Rebecca Johnson</div>
                                                        <div class="modal-review-date">October 10, 2025</div>
                                                        <div class="modal-review-rating">
                                                            <span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-review-content">
                                                    For our research and investment purposes, we require gold samples with precise documentation. Lubumbashi Gold Miners provides the most comprehensive geological and assaying data we have encountered from African suppliers. Their technical expertise is comparable to major mining corporations.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="review-card" data-bs-toggle="modal" data-bs-target="#reviewModal9">
                                    <div class="review-header">
                                        <div class="reviewer-info">
                                            <div class="reviewer-avatar">SC</div>
                                            <div class="reviewer-details">
                                                <div class="reviewer-name">Sarah Chen</div>
                                                <div class="review-date">September 11, 2025</div>
                                            </div>
                                        </div>
                                        <div class="review-rating">
                                            <span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star">★</span>
                                        </div>
                                    </div>
                                   
                                </div>
                                <div class="modal fade review-modal" id="reviewModal9" tabindex="-1" aria-labelledby="reviewModalLabel9" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="reviewModalLabel9">Feedback / Review</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="modal-reviewer-info">
                                                    <div class="modal-reviewer-avatar">SC</div>
                                                    <div class="modal-reviewer-details">
                                                        <div class="modal-reviewer-name">Sarah Chen</div>
                                                        <div class="modal-review-date">September 11, 2025</div>
                                                        <div class="modal-review-rating">
                                                            <span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star">★</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-review-content">
                                                    The transparency in their assaying process sets Lubumbashi Gold Miners apart. Every shipment arrives with complete documentation, and their purity standards consistently exceed our expectations. Their commitment to fair trade practices makes them our preferred partner in the DRC region.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="review-card" data-bs-toggle="modal" data-bs-target="#reviewModal1">
                                    <div class="review-header">
                                        <div class="reviewer-info">
                                            <div class="reviewer-avatar">SM</div>
                                            <div class="reviewer-details">
                                                <div class="reviewer-name">Samuel Mwamba</div>
                                                <div class="review-date">September 11, 2025</div>
                                            </div>
                                        </div>
                                        <div class="review-rating">
                                            <span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span>
                                        </div>
                                    </div>
                                   
                                </div>
                                <div class="modal fade review-modal" id="reviewModal1" tabindex="-1" aria-labelledby="reviewModalLabel1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="reviewModalLabel1">Feedback / Review</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="modal-reviewer-info">
                                                    <div class="modal-reviewer-avatar">SM</div>
                                                    <div class="modal-reviewer-details">
                                                        <div class="modal-reviewer-name">Samuel Mwamba</div>
                                                        <div class="modal-review-date">September 11, 2025</div>
                                                        <div class="modal-review-rating">
                                                            <span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-review-content">
                                                    Working with Lubumbashi Gold Miners has transformed our community. The transparency and fair practices ensure everyone benefits from our natural resources.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="review-card" data-bs-toggle="modal" data-bs-target="#reviewModal4">
                                    <div class="review-header">
                                        <div class="reviewer-info">
                                            <div class="reviewer-avatar">DM</div>
                                            <div class="reviewer-details">
                                                <div class="reviewer-name">David Mutombo</div>
                                                <div class="review-date">September 10, 2025</div>
                                            </div>
                                        </div>
                                        <div class="review-rating">
                                            <span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star">★</span>
                                        </div>
                                    </div>
                                   
                                </div>
                                <div class="modal fade review-modal" id="reviewModal4" tabindex="-1" aria-labelledby="reviewModalLabel4" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="reviewModalLabel4">Feedback / Review</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="modal-reviewer-info">
                                                    <div class="modal-reviewer-avatar">DM</div>
                                                    <div class="modal-reviewer-details">
                                                        <div class="modal-reviewer-name">David Mutombo</div>
                                                        <div class="modal-review-date">September 10, 2025</div>
                                                        <div class="modal-review-rating">
                                                            <span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star">★</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-review-content">
                                                    The gold testing services are professional and accurate. We now get fair prices for our gold based on actual purity levels.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="review-card" data-bs-toggle="modal" data-bs-target="#reviewModal5">
                                    <div class="review-header">
                                        <div class="reviewer-info">
                                            <div class="reviewer-avatar">SN</div>
                                            <div class="reviewer-details">
                                                <div class="reviewer-name">Sarah Ngalula</div>
                                                <div class="review-date">August 28, 2025</div>
                                            </div>
                                        </div>
                                        <div class="review-rating">
                                            <span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span>
                                        </div>
                                    </div>
                                   
                                </div>
                                <div class="modal fade review-modal" id="reviewModal5" tabindex="-1" aria-labelledby="reviewModalLabel5" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="reviewModalLabel5">Feedback / Review</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="modal-reviewer-info">
                                                    <div class="modal-reviewer-avatar">SN</div>
                                                    <div class="modal-reviewer-details">
                                                        <div class="modal-reviewer-name">Sarah Ngalula</div>
                                                        <div class="modal-review-date">August 28, 2025</div>
                                                        <div class="modal-review-rating">
                                                            <span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-review-content">
                                                    Excellent community development programs. The education initiatives have helped many children in our area.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="review-card" data-bs-toggle="modal" data-bs-target="#reviewModal2">
                                    <div class="review-header">
                                        <div class="reviewer-info">
                                            <div class="reviewer-avatar">MK</div>
                                            <div class="reviewer-details">
                                                <div class="reviewer-name">Marie Kabasele</div>
                                                <div class="review-date">August 10, 2025</div>
                                            </div>
                                        </div>
                                        <div class="review-rating">
                                            <span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star">★</span>
                                        </div>
                                    </div>
                                   
                                </div>
                                <div class="modal fade review-modal" id="reviewModal2" tabindex="-1" aria-labelledby="reviewModalLabel2" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="reviewModalLabel2">Feedback / Review</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="modal-reviewer-info">
                                                    <div class="modal-reviewer-avatar">MK</div>
                                                    <div class="modal-reviewer-details">
                                                        <div class="modal-reviewer-name">Marie Kabasele</div>
                                                        <div class="modal-review-date">August 10, 2025</div>
                                                        <div class="modal-review-rating">
                                                            <span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star">★</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-review-content">
                                                    I appreciate the focus on safety and environmental protection. The training programs have helped us mine more responsibly while increasing our yields.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="review-card" data-bs-toggle="modal" data-bs-target="#reviewModal8">
                                    <div class="review-header">
                                        <div class="reviewer-info">
                                            <div class="reviewer-avatar">JH</div>
                                            <div class="reviewer-details">
                                                <div class="reviewer-name">James Harrington</div>
                                                <div class="review-date">August 1, 2025</div>
                                            </div>
                                        </div>
                                        <div class="review-rating">
                                            <span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star">★</span>
                                        </div>
                                    </div>
                                   
                                </div>
                                <div class="modal fade review-modal" id="reviewModal8" tabindex="-1" aria-labelledby="reviewModalLabel8" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="reviewModalLabel8">Feedback / Review</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="modal-reviewer-info">
                                                    <div class="modal-reviewer-avatar">JH</div>
                                                    <div class="modal-reviewer-details">
                                                        <div class="modal-reviewer-name">James Harrington</div>
                                                        <div class="modal-review-date">August 1, 2025</div>
                                                        <div class="modal-review-rating">
                                                            <span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star filled">★</span><span class="star">★</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-review-content">
                                                    We have been sourcing gold from Lubumbashi Gold Miners for over three years, and their consistency in quality is remarkable. The XRF testing documentation they provide saves us significant time in our own verification process. Their ethical sourcing practices align perfectly with our compliance requirements.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Enhanced form validation and interactivity
        document.addEventListener('DOMContentLoaded', function() {
            const reviewForm = document.getElementById('reviewForm');
            const ratingInputs = document.querySelectorAll('.rating-input input');
            
            // Add hover effects to rating stars
            ratingInputs.forEach(input => {
                input.addEventListener('change', function() {
                    // Remove all active classes
                    document.querySelectorAll('.rating-input label').forEach(label => {
                        label.style.transform = 'scale(1)';
                    });
                    
                    // Add active class to selected and previous stars
                    const selectedValue = this.value;
                    document.querySelectorAll('.rating-input input').forEach(star => {
                        if(star.value <= selectedValue) {
                            star.nextElementSibling.style.transform = 'scale(1.1)';
                        }
                    });
                });
            });
            
            // Form submission enhancement
            reviewForm.addEventListener('submit', function(e) {
                const rating = document.querySelector('input[name="rating"]:checked');
                
                if(!rating) {
                    e.preventDefault();
                    alert('Please select a rating before submitting your review.');
                    return false;
                }
                
                // Add loading state
                const submitBtn = this.querySelector('button[type="submit"]');
                const originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Submitting...';
                submitBtn.disabled = true;
                
                // Re-enable button after 3 seconds (in case submission fails)
                setTimeout(() => {
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                }, 3000);
            });
            
            // Smooth scroll for reviews container
            const reviewsContainer = document.querySelector('.reviews-container');
            if(reviewsContainer) {
                reviewsContainer.addEventListener('wheel', function(e) {
                    if(!e.deltaY) return;
                    e.preventDefault();
                    this.scrollTop += e.deltaY;
                });
            }

            // Add click animation to review cards
            const reviewCards = document.querySelectorAll('.review-card');
            reviewCards.forEach(card => {
                card.addEventListener('click', function() {
                    this.style.transform = 'scale(0.98)';
                    setTimeout(() => {
                        this.style.transform = '';
                    }, 150);
                });
            });
        });
    </script> 

<!-- Contact Section -->
<section id="contact" class="contact-section py-5">
    <div class="container">
        <h2 class="section-title text-center mb-5">Contact Us</h2>
        
        <div class="row">
            <!-- Contact Form -->
            <div class="col-lg-6 mb-5">
                <div class="contact-form-wrapper">
                    <h4 class="contact-heading">Send Us a Message</h4>
                    <p class="contact-description">Have questions or want to partner with us? We'd love to hear from you.</p>
                    
                    <form id="contactForm" class="contact-form" method="POST" action="send_mail.php">
    <div class="row">
        <div class="col-md-6 mb-3">
            <div class="form-group">
                <label for="name" class="form-label">Your Name *</label>
                <input type="text" class="form-control" name="name" id="name" placeholder="Enter your full name" required>
            </div>
        </div>
        <div class="col-md-6 mb-3">
            <div class="form-group">
                <label for="email" class="form-label">Your Email *</label>
                <input type="email" class="form-control" name="email" id="email" placeholder="Enter your email address" required>
            </div>
        </div>
    </div>

    <div class="mb-3">
        <div class="form-group">
            <label for="subject" class="form-label">Subject *</label>
            <input type="text" class="form-control" name="subject" id="subject" placeholder="What is this regarding?" required>
        </div>
    </div>

    <div class="mb-3">
        <div class="form-group">
            <label for="message" class="form-label">Your Message *</label>
            <textarea class="form-control" name="message" id="message" rows="5" placeholder="Tell us how we can help you..." required></textarea>
        </div>
    </div>

    <div class="mb-3">
        <div class="form-check">
            <input type="checkbox" class="form-check-input" name="newsletter" id="newsletter">
            <label class="form-check-label" for="newsletter">
                Subscribe to our newsletter for updates
            </label>
        </div>
    </div>

    <button type="submit" class="btn btn-primary btn-lg w-100">
        <i class="fas fa-paper-plane me-2"></i>
        Send Message
    </button>
</form>

                </div>
            </div>
            
            <!-- Google Maps -->
            <div class="col-lg-6">
                <div class="map-section">
                    <h4 class="map-heading">Find Us Here</h4>
                    <div class="map-container">
                        <div id="googleMap" class="google-map">
                            <!-- Fallback content if maps doesn't load -->
                            <div class="map-fallback">
                                <div class="fallback-content">
                                    <i class="fas fa-map-marked-alt"></i>
                                    <h5>Interactive Map</h5>
                                    <p>View our location in Lubumbashi Mining District</p>
                                    <a href="https://maps.google.com/maps?q=Lubumbashi+Mining+District+Democratic+Republic+of+Congo" 
                                       target="_blank" class="btn btn-outline-primary">
                                        Open in Google Maps
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                </div>
            </div>
        </div>
        
        <!-- Contact Information -->
      
  
        
            <div class="contact-info-card">
                <h4 class="contact-heading text-center mb-4">Get In Touch</h4>
                <p class="contact-description text-center mb-5">We'd love to hear from you. Reach out to us through any of the following channels:</p>
                
                <div class="row justify-content-center">
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 mb-4">
                        <div class="contact-info-item text-center">
                            <div class="contact-icon mx-auto">
                                <i class="fas fa-map-marker-alt"></i>
                            </div>
                            <div class="contact-text">
                                <h5>Our Location</h5>
                                <p>Lubumbashi Mining District<br>Democratic Republic of Congo</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 mb-4">
                        <div class="contact-info-item text-center">
                            <div class="contact-icon mx-auto">
                                <i class="fas fa-phone"></i>
                            </div>
                            <div class="contact-text">
                                <h5>Phone Number</h5>
                                <ul class="list-unstyled">
                        
                         <li>
                            <a href="tel:+256746317422" style="text-decoration: none; color: inherit;">
                                <i class="fas fa-phone"></i> +256 746317422
                            </a>
                            </li>
                        <li><i class="fa fa-whatsapp"></i> +254 707043495</li>
                        <li><i class="fa fa-whatsapp"></i> +243 906263852</li>
                       
                        <li><i class="fa fa-whatsapp"></i> +243 897295691</li>
                        
                    </ul>
                               
                                
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 mb-4">
                        <div class="contact-info-item text-center">
                            <div class="contact-icon mx-auto">
                                <i class="fas fa-envelope"></i>
                            </div>
                            <div class="contact-text">
                                <h5>Email Address</h5>
                                <p>info@lubumbashigoldminers.com<br>part@lubumbashigoldminers.com</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 mb-4">
                        <div class="contact-info-item text-center">
                            <div class="contact-icon mx-auto">
                                <i class="fas fa-clock"></i>
                            </div>
                            <div class="contact-text">
                                <h5>Working Hours</h5>
                                <p>Monday: Fri: 8:00 AM - 6:00 PM<br>Sat: 9:00 AM - 2:00 PM</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="social-contact text-center mt-4">
                    <h5>Follow Us</h5>
                    <div class="social-links justify-content-center">
                        <a href="#" class="social-link">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" class="social-link">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="#" class="social-link">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                        <a href="#" class="social-link">
                            <i class="fab fa-instagram"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>


   
</section>
</main>    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lubumbashi Gold Miners</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* General Footer Styles */
        .footer {
            background-color: #2c3e50;
            color: #ecf0f1;
            margin-top: 50px;
        }
        
        .footer h5, .footer h6 {
            color: #f1c40f;
            margin-bottom: 15px;
        }
        
        .footer a {
            color: #ecf0f1;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer a:hover {
            color: #f1c40f;
        }
        
        .social-links a {
            display: inline-block;
            margin-right: 15px;
            font-size: 20px;
        }
        
        /* Custom Modal Styles */
        .disclaimer-modal .modal-content {
            background-color: #1a1a1a;
            color: white;
            border: 3px solid #f1c40f;
            border-radius: 10px;
        }
        
        .disclaimer-modal .modal-header {
            border-bottom: 0px solid #f1c40f;
            background-color: #2c3e50;
        }
        
        .disclaimer-modal .modal-title {
            color: #f1c40f;
            font-weight: bold;
        }
        
        .disclaimer-modal .btn-close {
            filter: invert(1);
        }
        
        .disclaimer-modal .modal-footer {
            border-top: 0px solid #f1c40f;
        }
        
        .disclaimer-modal .btn-primary {
            background-color: #f1c40f;
            border-color: #f1c40f;
            color: #2c3e50;
            font-weight: bold;
        }
        
        .disclaimer-modal .btn-primary:hover {
            background-color: #f39c12;
            border-color: #f39c12;
        }
        
        .disclaimer-modal .btn-secondary {
            background-color: #7f8c8d;
            border-color: #7f8c8d;
        }
        
        .disclaimer-modal .btn-secondary:hover {
            background-color: #95a5a6;
            border-color: #95a5a6;
        }
        
        /* WhatsApp Button Styles */
        .whatsapp-float {
            position: fixed;
            width: 60px;
            height: 60px;
            bottom: 40px;
            right: 40px;
            background-color: #25d366;
            color: #FFF;
            border-radius: 50px;
            text-align: center;
            font-size: 30px;
            box-shadow: 2px 2px 3px #999;
            z-index: 100;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            animation: pulse 2s infinite;
            cursor: pointer;
        }
        
        .whatsapp-float:hover {
            background-color: #128C7E;
            transform: scale(1.1);
            box-shadow: 3px 3px 10px rgba(0, 0, 0, 0.3);
        }
        
        @keyframes pulse {
            0% {
                box-shadow: 0 0 0 0 rgba(37, 211, 102, 0.7);
            }
            70% {
                box-shadow: 0 0 0 10px rgba(37, 211, 102, 0);
            }
            100% {
                box-shadow: 0 0 0 0 rgba(37, 211, 102, 0);
            }
        }
        
        /* Tooltip */
        .whatsapp-tooltip {
            position: absolute;
            right: 70px;
            bottom: 20px;
            background-color: #333;
            color: white;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 14px;
            opacity: 0;
            transition: opacity 0.3s;
            pointer-events: none;
            white-space: nowrap;
        }
        
        .whatsapp-float:hover .whatsapp-tooltip {
            opacity: 1;
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .whatsapp-float {
                width: 50px;
                height: 50px;
                bottom: 20px;
                right: 20px;
                font-size: 25px;
            }
            
            .whatsapp-tooltip {
                right: 60px;
                font-size: 12px;
            }
        }
        
        /* Custom styles for WhatsApp tracking */
        .whatsapp-tracked {
            background-color: #128C7E !important;
        }
        
        .whatsapp-tracked:after {
            content: '✓';
            position: absolute;
            top: -5px;
            right: -5px;
            background: #f1c40f;
            color: #2c3e50;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            font-size: 12px;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
</head>
<body>

    <!-- Your main content here -->

    <!-- Footer -->
    <footer class="footer py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <h5>Lubumbashi Gold Miners</h5>
                    <p>Committed to ethical mining practices and community development in the Democratic Republic of Congo.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-6 mb-4">
                    <h6>Quick Links</h6>
                    <ul class="list-unstyled">
                        <li><a href="#home">Home</a></li>
                        <li><a href="#about">About</a></li>
                        <li><a href="#process">Our Process</a></li>
                        <li><a href="#products">Products</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-6 mb-4">
                    <h6>Resources</h6>
                    <ul class="list-unstyled">
                        <li><a href="#">Certifications</a></li>
                        <li><a href="#">Sustainability Report</a></li>
                        <li><a href="#">Community Projects</a></li>
                        <li><a href="#">FAQs</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 mb-4">
                    <h6>Contact Information</h6>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-map-marker-alt"></i> Lubumbashi, DRC</li>
                        <li>
                            <a href="tel:+256746317422" style="text-decoration: none; color: inherit;">
                                <i class="fas fa-phone"></i> +256 746317422
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" onclick="trackWhatsAppClick('+254707043495')" class="whatsapp-contact">
                                <i class="fab fa-whatsapp"></i> +254 707043495
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" onclick="trackWhatsAppClick('+243906263852')" class="whatsapp-contact">
                                <i class="fab fa-whatsapp"></i> +243 906263852
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" onclick="trackWhatsAppClick('+243897295691')" class="whatsapp-contact">
                                <i class="fab fa-whatsapp"></i> +243 897295691
                            </a>
                        </li>
                        <li><i class="fas fa-envelope"></i> info@lubumbashigoldminers.com</li>
                    </ul>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-6">
                    <p>&copy; 2024 Lubumbashi Community Gold Miners. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <a href="#" data-bs-toggle="modal" data-bs-target="#disclaimerModal">Disclaimer</a> | 
                    <a href="#">Privacy Policy</a> | 
                    <a href="#">Terms of Service</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Disclaimer Modal -->
    <div class="modal fade disclaimer-modal" id="disclaimerModal" tabindex="-1" aria-labelledby="disclaimerModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="disclaimerModalLabel">
                        <i class="fas fa-exclamation-triangle me-2"></i>Important Disclaimer
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>To prevent scams and fraudulent activities, we strongly advise all foreign investors and gold buyers to conduct proper due diligence before engaging in any business involving gold from the Democratic Republic of Congo (DRC).</p>
                    
                    <p>Be cautious of individuals or groups claiming partnerships with Congolese communities, military generals, or government officials without official verification.</p>
                    
                    <p>Please note that the Head Chief of Lubumbashi serves as the Board Chairman for all Community Gold Miners in the DRC, and all legitimate community gold dealings are coordinated under this office.</p>
                    
                    <div class="alert alert-warning mt-3">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong>For verification or inquiries:</strong> Contact us via WhatsApp for official guidance and assistance.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <a href="javascript:void(0);" onclick="trackWhatsAppModalClick()" class="btn btn-primary">
                        <i class="fab fa-whatsapp me-2"></i>Contact via WhatsApp
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- WhatsApp Floating Button -->
    <div class="whatsapp-float" id="whatsappButton" onclick="trackWhatsAppFloatClick()">
        <i class="fab fa-whatsapp"></i>
        <span class="whatsapp-tooltip">Chat with us on WhatsApp</span>
    </div>

    <!-- Hidden tracking form -->
    <form id="whatsappTrackForm" method="POST" action="track-whatsapp.php" target="_blank" style="display: none;">
        <input type="hidden" name="phone_number" id="trackPhoneNumber" value="+243906263852">
        <input type="hidden" name="message" id="trackMessage" value="Hello Lubumbashi Community Gold Miners, I would like to get more information about your services">
        <input type="hidden" name="source" id="trackSource" value="floating_button">
        <input type="hidden" name="page_url" id="trackPageUrl" value="/index.php">
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Automatically show the disclaimer modal when the page loads
        document.addEventListener('DOMContentLoaded', function() {
            // Check if user has already accepted the disclaimer
            if (!localStorage.getItem('disclaimerAccepted')) {
                // Show the modal after a short delay
                setTimeout(function() {
                    var disclaimerModal = new bootstrap.Modal(document.getElementById('disclaimerModal'));
                    disclaimerModal.show();
                    
                    // Set a flag when modal is closed
                    document.getElementById('disclaimerModal').addEventListener('hidden.bs.modal', function () {
                        localStorage.setItem('disclaimerAccepted', 'true');
                    });
                }, 1000);
            }
            
            // Add click event to the disclaimer link in footer
            document.querySelector('a[data-bs-target="#disclaimerModal"]').addEventListener('click', function() {
                var disclaimerModal = new bootstrap.Modal(document.getElementById('disclaimerModal'));
                disclaimerModal.show();
            });
            
            // Initialize page URL for tracking
            document.getElementById('trackPageUrl').value = window.location.href;
            
            // Check if WhatsApp click was already tracked in this session
            if (sessionStorage.getItem('whatsappClicked')) {
                document.getElementById('whatsappButton').classList.add('whatsapp-tracked');
            }
        });

        // Function to track WhatsApp clicks from floating button
        function trackWhatsAppFloatClick() {
            trackWhatsAppClick('+243906263852', 'Hello Lubumbashi Community Gold Miners, I would like to get more information about your services', 'floating_button');
        }

        // Function to track WhatsApp clicks from modal button
        function trackWhatsAppModalClick() {
            trackWhatsAppClick('+243906263852', 'Hello Lubumbashi Community Gold Miners, I would like to verify and get more information about your services', 'modal_button');
        }

        // Function to track WhatsApp clicks from contact numbers
        function trackWhatsAppClick(phoneNumber, message = '', source = 'contact_number') {
            // Default message if not provided
            if (!message) {
                message = 'Hello Lubumbashi Community Gold Miners, I would like to get more information about your services';
            }
            
            // Set tracking values
            document.getElementById('trackPhoneNumber').value = phoneNumber;
            document.getElementById('trackMessage').value = message;
            document.getElementById('trackSource').value = source;
            
            // Submit the tracking form
            document.getElementById('whatsappTrackForm').submit();
            
            // Open WhatsApp in a new tab (as backup)
            const whatsappUrl = `https://wa.me/${phoneNumber.replace('+', '')}?text=${encodeURIComponent(message)}`;
            window.open(whatsappUrl, '_blank');
            
            // Mark as tracked in this session
            sessionStorage.setItem('whatsappClicked', 'true');
            document.getElementById('whatsappButton').classList.add('whatsapp-tracked');
            
            // Send tracking data via AJAX
            sendWhatsAppTracking(phoneNumber, source, message);
            
            return false;
        }

        // Function to send WhatsApp tracking data via AJAX
        function sendWhatsAppTracking(phoneNumber, source, message) {
            const data = {
                phone_number: phoneNumber,
                source: source,
                message: message,
                page_url: window.location.href,
                user_agent: navigator.userAgent,
                timestamp: new Date().toISOString()
            };
            
            // Send tracking data
            fetch('ajax-track-whatsapp.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(data => {
                console.log('WhatsApp click tracked:', data);
            })
            .catch(error => {
                console.error('Tracking error:', error);
            });
        }

        // Function to track page views
        function trackPageView() {
            const data = {
                action: 'track_pageview',
                page_url: window.location.href,
                referrer: document.referrer
            };
            
            fetch('ajax-track-visitor.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(data => {
                console.log('Page view tracked:', data);
                if (data.visitor_id) {
                    localStorage.setItem('visitor_id', data.visitor_id);
                }
            })
            .catch(error => {
                console.error('Page tracking error:', error);
            });
        }

        // Track page view on load
        window.addEventListener('load', function() {
            // Only track if not already tracked in this session
            if (!sessionStorage.getItem('pageTracked')) {
                trackPageView();
                sessionStorage.setItem('pageTracked', 'true');
            }
        });
    </script>
</body>
</html>    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>